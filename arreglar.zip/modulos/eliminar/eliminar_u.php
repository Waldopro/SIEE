<?php
include('../verificar_session.php');
include '../rol1.php';
include '../conexion/conndb.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id = $_GET["id"];

   
        // Consulta preparada para eliminar el usuario con el ID proporcionado
        $sql_delete_user = "DELETE FROM usuarios WHERE id = ?";
        $stmt_delete_user = $conexion->prepare($sql_delete_user);
        $stmt_delete_user->bind_param("i", $id);

        if ($stmt_delete_user->execute()) {
            echo "Usuario eliminado con éxito.";
        } else {
            echo "Error al eliminar el usuario: " . $stmt_delete_user->error;
        }

        $stmt_delete_user->close();

    $conexion->close();

    header("Location: ../procesar/procesalogin.php?eliminacion_exitosa=true..php");
    exit();
}
?>
