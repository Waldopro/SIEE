<?php

include '../verificar_session.php';
include '../conexion/conndb.php';

if (!$conexion) {
    die("Conexion fallida: " . mysqli_connect_error());
}


$id_estudiante = $_GET["id"];


$consulta = "DELETE FROM estudiante WHERE id_estudiante='$id_estudiante'";
$resultado = mysqli_query($conexion, $consulta);

if (!$resultado) {
    die("Error al eliminar: " . mysqli_error($conexion));
}

header("location: ../procesar/procesare.php?eliminacion_exitosa=true.");
mysqli_close($conexion);
?>
