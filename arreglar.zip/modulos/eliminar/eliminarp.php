<?php
// Iniciar sesión
include '../verificar_session.php';

include '../conexion/conndb.php';

// Verificar si se recibió el parámetro "id" en la URL
if(isset($_GET['id'])) {
    $id_padre_madre = $_GET['id'];
    
    $consulta = "DELETE FROM padre_madre WHERE id_padre_madre='$id_padre_madre'";
    $resultado = mysqli_query($conexion, $consulta);
    
    if (!$resultado) {
        die("Error al eliminar: " . mysqli_error($conexion));
    }
    
    header("location: ../procesar/procesarp.php?eliminacion_exitosa=true.");
} else {
    echo "No se recibió el parámetro 'id' en la URL";
}

mysqli_close($conexion);
?>

