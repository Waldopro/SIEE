<?php
include '../verificar_session.php';
include '../cpnexion/conndb.php';

// Verificar si se recibió el parámetro "id" en la URL
if(isset($_GET['id'])) {
    $id_representante = $_GET['id'];
    
    $consulta = "DELETE FROM representante WHERE id_representante='$id_representante'";
    $resultado = mysqli_query($conexion, $consulta);
    
    if (!$resultado) {
        die("Error al eliminar: " . mysqli_error($conexion));
    }
    
    header("location: ../procesar/procesarr.php?eliminacion_exitosa=true.");
} else {
    echo "No se recibió el parámetro 'id' en la URL";
}

mysqli_close($conexion);
?>
