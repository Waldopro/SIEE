<?php 
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
include('verificar_session.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acerca de Nosotros</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../css/inicio.css">
    <script src="../js/tiempo_sesion.js"></script>
    <script src="../js/alerta.js"></script>
    <script src="../js/menu.js"></script>
    <script src="../js/sweetalert211.js"></script>
    <script src="../js/sweetalert.min.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="j../s/bootstrap.min.js"></script>
<script type="text/javascript" src="../js/fontawesome.js"></script>
<link rel="stylesheet" href="../css/footer.css">
</head>
<body oncontextmenu="return false;">
<div class="wrapper">
<?php include('menu.php') ?>

<div class="container">
    <div class="content">
    <h1 class=""><center>Acerca de nosotros</center></h1>
    <section class="intro">
        <h2>Quiénes Somos</h2>
        <p>Somos unos estudiantes de la U.P.T.P "Luis Mariano Rivero" extensión Cajigal que 
            nos dedicamos día a día a aprender e implementar cosas nuevas para asi mejorar
            nuestros sistemas que estamos elaborando.</p>
    </section>


    <section class="team">
        <h2>Conoce a Nuestro Equipo</h2>
        <div class="team-member">
            <img src="../img/equipo/foto1.jpg" alt="Foto del miembro del equipo">
            <h3>Oswaldo Monasterio</h3>
            <p>[Breve biografía del miembro del equipo]</p>
        </div>
        <div class="team-member">
            <img src="../img/equipo/foto2.jpeg" alt="Foto del miembro del equipo">
            <h3>Danny Marcano</h3>
            <p>[Breve biografía del miembro del equipo]</p>
        </div>
        <div class="team-member">
            <img src="../img/equipo/foto3.jpg" alt="Foto del miembro del equipo">
            <h3>Yudennys Espinoza</h3>
            <p>[Breve biografía del miembro del equipo]</p>
        </div>
    </section>

    <section class="contact">
        <h2>Contacto</h2>
        <p>Puedes contactarnos en:</p>
        <p>Email: oswaldojmonasterioa@gmail.com, </p>
        <p>Teléfono: 04248205484, 04124466061 y 04123474422</p>
    </section>
    </div>
        </div>
    <div class="footer">
    <?php include 'footer.php';?></div>
    
</body>
</html>
