<?php
include '../error.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
// Verificar si el usuario ha iniciado sesión y si su rol es de "usuario"
include('../verificar_session.php');

include '../conexion/conndb.php';


if (isset($_POST['update'])) {
	$id_estudiante = $_POST['id_estudiante'];
	$apellidos_e = $_POST['apellidos_e'];
	$nombres_e = $_POST['nombres_e'];
	$fecha_nac = $_POST['fecha_nac'];
	$edad_e = $_POST['edad_e'];
	$sexo = $_POST['sexo'];
	$peso = $_POST['peso'];
	$talla = $_POST['talla'];
	$lugar_nac = $_POST['lugar_nac'];
	$municipio = $_POST['municipio'];
	$estado = $_POST['estado'];
	$parroquia = $_POST['parroquia'];
	$direccion_e = $_POST['direccion_e'];
	$tel_e = $_POST['tel_e'];
	$posee_can = $_POST['posee_can'];
	$serial_can = $_POST['serial_can'];
	$becado = $_POST['becado'];
	$seccion_e = $_POST['seccion_id'];
	$grado_e = $_POST['grado_id'];
	$ins_para = $_POST['ins_para'];
    $tipo_ins = $_POST['tipo_ins'];
	$fotos = $_POST['fotos'];
	$copias_ci = $_POST['copias_ci'];
	$partida_nac_co = $_POST['partida_nac_co'];
	$historia_esc = $_POST['historia_esc'];
	$cert_prom = $_POST['cert_prom'];
	$tarj_vac = $_POST['tarj_vac'];
	$cons_conduc = $_POST['cons_conduc'];
	$cons_retiro = $_POST['cons_retiro'];
	$cert_notas = $_POST['cert_notas'];

	$sql = "UPDATE estudiante SET 
		apellidos_e='$apellidos_e',
		nombres_e='$nombres_e',
		fecha_nac='$fecha_nac',
		edad_e='$edad_e',
		sexo='$sexo',
		peso='$peso',
		talla='$talla',
		lugar_nac='$lugar_nac',
		municipio='$municipio',
		estado='$estado',
		parroquia='$parroquia',
		direccion_e='$direccion_e',
		tel_e='$tel_e',
		posee_can='$posee_can',
		serial_can='$serial_can',
		becado='$becado',
		seccion_id='$seccion_e',
		grado_id='$grado_e',
		tipo_ins='$tipo_ins',
		fotos='$fotos',
		copias_ci='$copias_ci',
		partida_nac_co='$partida_nac_co',
		historia_esc='$historia_esc',
		cert_prom='$cert_prom',
		tarj_vac='$tarj_vac',
		cons_conduc='$cons_conduc',
		cons_retiro='$cons_retiro',
		cert_notas='$cert_notas'
	WHERE id_estudiante='$id_estudiante'";

	if ($conexion->query($sql) === TRUE) {
		header("Location: ../procesar/procesare.php?edicion_exitosa=true.");
		exit();
	} else {
		echo "Error: " . $sql . "<br>" . $conexion->error;
	}
}
// Obtener el valor de id_estudiante de la URL
if (isset($_GET['id'])) {
	$id_estudiante = $_GET['id'];

	$sql = "SELECT * FROM estudiante WHERE id_estudiante='$id_estudiante'";
	$result = $conexion->query($sql);
	$row = $result->fetch_assoc();
	$conexion->close();
} else {
	echo "No se recibió el parámetro 'id' en la URL";
	header('location:../procesar/procesare.php?edicion_exitosa=true.');
}	
	
?>	
	
<!DOCTYPE html>
<html lang="es">
	
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Editar Datos Del Estudiante</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../../css/inicio.css">
    <link rel="stylesheet" type="text/css" href="../../css/editare.css">
    <link rel="stylesheet" type="text/css" href="../../css/registro_e.css">
	<link rel="stylesheet" href="../../css/footer.css">
    <script src="../../node_modules/jquery/dist/jquery.min.js"></script>
</head>

<body oncontextmenu="return false;">
	
	<?php include('../menu.php') ?>
<center><h2 class="h1">Editar Estudiante</h2></center>
	<form id="form" action="editare.php" method="post">
		<div class="contenedor-formularios">
			<div class="formulario">
				<h1 class="animate__animated animate__backInLeft">Datos del Alumno</h1>

				<input type="hidden" name="id_estudiante" value="<?php echo $id_estudiante; ?>"readonly>

				<label>Cédula:</label>
				<input type="number" name="cedula_e" value="<?php echo $row['cedula_e']; ?>" disabled>

				<label>Apellidos:</label>
				<input type="text" name="apellidos_e" value="<?php echo $row['apellidos_e']; ?>" required>
				<label>Nombres:</label>
				<input type="text" name="nombres_e" value="<?php echo $row['nombres_e']; ?>" required>
				<label>Fecha de Nacimiento:</label>
<input type="date" name="fecha_nac" value="<?php echo date('Y-m-d', strtotime($row['fecha_nac'])); ?>" required>
<label>Edad:</label>
<input id="edad" name="edad_e" type="number" inputmode="numeric" pattern="\d{1,2}" maxlength="2" value="<?php echo $row['edad_e']; ?>" required readonly><br><br>
				<label>Sexo:</label>
				<select name="sexo" required>
					<option value="Masculino" <?php if (isset($sexo) && $sexo == 'Masculino') {
													echo 'selected';
												} ?>>Masculino</option>
					<option value="Femenino" <?php if (isset($sexo) && $sexo == 'Femenino') {
													echo 'selected';
												} ?>>Femenino</option>
				</select>
				<label>Lugar de Nacimiento:</label>
				<input type="text" name="lugar_nac" value="<?php echo $row['lugar_nac']; ?>" required>

				<label>Estado:</label>
				<select name="estado" id="estado" required>
				
				</select>

				<label>Municipio:</label>
				<select name="municipio" id="municipio" required>
				    
				</select>

				<label>Parroquia:</label>
				<select name="parroquia" id="parroquia" required>
				    
				</select>

				<label>Dirección:</label>
				<input type="text" name="direccion_e" value="<?php echo $row['direccion_e']; ?>" required>
			</div>

			<div class="formulario">
				
					<h1 class="animate__animated animate__backInLeft">Información Adicional</h1>
					<label>Teléfono:</label>
					<input type="tel" id="tel_e" name="tel_e" value="<?php echo $row['tel_e']; ?>" required>
					<label>Peso:</label>
					<input type="text" name="peso" value="<?php echo $row['peso']; ?>" required>
					<label for="talla">Talla:</label>
					<select name="talla" required>
						<option value="SS" <?php if ($row['talla'] == 'SS') echo 'selected'; ?>>SS</option>
						<option value="S" <?php if ($row['talla'] == 'S') echo 'selected'; ?>>S</option>
						<option value="M" <?php if ($row['talla'] == 'M') echo 'selected'; ?>>M</option>
						<option value="L" <?php if ($row['talla'] == 'L') echo 'selected'; ?>>L</option>
					</select>
					<label>Posee Canaima:</label>
					<select name="posee_can" id="posee_can" required>
					<option value="Seleccione"<?php if ($row['posee_can'] == 'Seleccione') echo 'selected'; ?>>Seleccione</option>
						<option value="Si" <?php if ($row['posee_can'] == 'Si') {
												echo 'selected';
											} ?>>Si</option>
						<option value="No" <?php if ($row['posee_can'] == 'No') {
												echo 'selected';
											} ?>>No</option>
					</select>
					<label for="serial_can">Serial del Canaima:</label>
					<input type="text" id="serial_can" name="serial_can" value="<?php echo $row['serial_can']; ?>">
					<span id="no_canaima_text" style="display: none;">No posee Canaima</span>

					<label>Becado:</label>
					<select name="becado" required>
						<option value="Si" <?php if ($row['becado'] == 'Si') {
												echo 'selected';
											} ?>>Si</option>
						<option value="No" <?php if ($row['becado']  == 'No') {
												echo 'selected';
											} ?>>No</option>

					</select>
					<label for="ins_para">Inscrito para el año:</label>
					<input type="number" name="ins_para" id="ins_para" value="<?php echo $row['ins_para']; ?>" required>
					
					</select>
					<label for="tipo_ins">Tipo de inscripcion:</label>
					<select name="tipo_ins" id="tipo_ins">
                        <option value="Seleccione"<?php if ($row['tipo_ins'] == 'Seleccione') echo 'selected'; ?>>Seleccione un tipo de inscripción</option>
                        <option value="Nuevo"<?php if ($row['tipo_ins'] == 'Nuevo') echo 'selected'; ?>>Nuevo</option>
                        <option value="Regular"<?php if ($row['tipo_ins'] == 'Regular') echo 'selected'; ?>>Regular</option>
                        <option value="Repitiente"<?php if ($row['tipo_ins'] == 'Repitiente') echo 'selected'; ?>>Repitiente</option>
                    </select>
					
					 
					<label for="grado_id">Grado:</label>
					<select id="grado_id" name="grado_id" onchange="updateSecciones()" required>
						<option value="">--Seleccione--</option>
						<option value="1" <?php if ($row['grado_id'] == '1') echo 'selected'; ?>>Preescolar</option>
						<option value="2" <?php if ($row['grado_id'] == '2') echo 'selected'; ?>>1ro</option>
						<option value="3" <?php if ($row['grado_id'] == '3') echo 'selected'; ?>>2do</option>
						<option value="4" <?php if ($row['grado_id'] == '4') echo 'selected'; ?>>3ro</option>
						<option value="5" <?php if ($row['grado_id'] == '5') echo 'selected'; ?>>4to</option>
						<option value="6" <?php if ($row['grado_id'] == '6') echo 'selected'; ?>>5to</option>
						<option value="7" <?php if ($row['grado_id'] == '7') echo 'selected'; ?>>6to</option>
					</select>
					<label for="seccion_id">Sección:</label>
					<select id="seccion_id" name="seccion_id">
						<option value="">--Seleccione--</option>
						<option value="1" <?php if ($row['seccion_id'] == '1') echo 'selected'; ?>>Etapa 1</option>
						<option value="2" <?php if ($row['seccion_id'] == '2') echo 'selected'; ?>>Etapa 2</option>
						<option value="3" <?php if ($row['seccion_id'] == '3') echo 'selected'; ?>>Etapa 3</option>
						<option value="4" <?php if ($row['seccion_id'] == '4') echo 'selected'; ?>>A</option>
						<option value="5" <?php if ($row['seccion_id'] == '5') echo 'selected'; ?>>B</option>
						<option value="6" <?php if ($row['seccion_id'] == '6') echo 'selected'; ?>>C</option>
										</select><br>
			</div>
			<div class="formulario">
				
					<h1 class="animate__animated animate__backInLeft">Documentos Consignados</h1>
					<label for="fotos">Fotos tipo Carnet:</label>
					<select id="fotos" name="fotos" required>
						<option value="Si" <?php if ($row['fotos'] == 'Si') echo ' selected'; ?>>Si</option>
						<option value="No" <?php if ($row['fotos'] == 'No') echo ' selected'; ?>>No</option>
					</select><br>
					<label for="copias_ci">Copias de Cedula:</label>
					<select id="copias_ci" name="copias_ci" required>
						<option value="">--Seleccione--</option>
						<option value="Si" <?php if ($row['copias_ci'] == 'Si') echo ' selected'; ?>>Si</option>
						<option value="No" <?php if ($row['copias_ci'] == 'No') echo ' selected'; ?>>No</option>
					</select><br>
					<label for="partida_nac_co">Partida de Nacimiento Copia:</label>
					<select id="partida_nac_co" name="partida_nac_co" required>
						<option value="">--Seleccione--</option>
						<option value="Si" <?php if ($row['partida_nac_co'] == 'Si') echo ' selected'; ?>>Si</option>
						<option value="No" <?php if ($row['partida_nac_co'] == 'No') echo ' selected'; ?>>No</option>
					</select><br>
					<label for="historia_esc">Historia Escolar:</label>
					<select id="historia_esc" name="historia_esc" required>
						<option value="">--Seleccione--</option>
						<option value="Si" <?php if ($row['historia_esc'] == 'Si') echo ' selected'; ?>>Si</option>
						<option value="No" <?php if ($row['historia_esc'] == 'No') echo ' selected'; ?>>No</option>
					</select><br>
					<label for="cert_prom">Certificado de Promoción:</label>
					<select id="cert_prom" name="cert_prom" required>
						<option value="">--Seleccione--</option>
						<option value="Si" <?php if ($row['cert_prom'] == 'Si') echo ' selected'; ?>>Si</option>
						<option value="No" <?php if ($row['cert_prom'] == 'No') echo ' selected'; ?>>No</option>
					</select><br>
					<label for="tarj_vac">Tarjeta de vacunas:</label>
					<select id="tarj_vac" name="tarj_vac" required>
						<option value="">--Seleccione--</option>
						<option value="Si" <?php if ($row['tarj_vac'] == 'Si') echo ' selected'; ?>>Si</option>
						<option value="No" <?php if ($row['tarj_vac'] == 'No') echo ' selected'; ?>>No</option>
					</select><br>
					<label for="cons_conduc">Constancia de Buena Conducta:</label>
					<select id="cons_conduc" name="cons_conduc" required>
						<option value="">--Seleccione--</option>
						<option value="Si" <?php if ($row['cons_conduc'] == 'Si') echo ' selected'; ?>>Si</option>
						<option value="No" <?php if ($row['cons_conduc'] == 'No') echo ' selected'; ?>>No</option>
					</select><br>
					<label for="cons_retiro">Constancia de Retiro:</label>
					<select id="cons_retiro" name="cons_retiro" required>
						<option value="">--Seleccione--</option>
						<option value="Si" <?php if ($row['cons_retiro'] == 'Si') echo ' selected'; ?>>Si</option>
						<option value="No" <?php if ($row['cons_retiro'] == 'No') echo ' selected'; ?>>No</option>
					</select><br>
					<label for="cert_notas">Certificado de Notas:</label>
					<select id="cert_notas" name="cert_notas" required>
						<option value="">--Seleccione--</option>
						<option value="Si" <?php if ($row['cert_notas'] == 'Si') echo ' selected'; ?>>Si</option>
						<option value="No" <?php if ($row['cert_notas'] == 'No') echo ' selected'; ?>>No</option>
					</select><br>

					<input class="btn btn-primary" type='submit' name="update" value="Actualizar">
					<a href="../procesar/procesare.php" class="back-button">Volver</a>

				</div>
										</div>
	</form>	
	<div class="footer">
    <p>Proyecto <?php echo date('Y'); ?> UPTP CAJIGAL &copy; Todos los derechos reservados</p>
</div> 
<script type="text/javascript" src="../../lib/venezuela.js"></script>
<script>
	var poseeCanSelect = document.getElementById("posee_can");
var serialCanInput = document.getElementById("serial_can");
var noCanaimaText = document.getElementById("no_canaima_text");

poseeCanSelect.addEventListener("change", function() {
    if (poseeCanSelect.value === "No") {
        serialCanInput.style.display = "none";
        serialCanInput.removeAttribute("required");
        noCanaimaText.style.display = "inline"; // Muestra el texto "No posee Canaima"
    } else {
        serialCanInput.style.display = "block";
        serialCanInput.setAttribute("required", "");
        noCanaimaText.style.display = "none"; // Oculta el texto "No posee Canaima"
    }
});
	document.getElementById('tel_e').addEventListener('input', function (e) {
  e.target.value = e.target.value.replace(/[^\d]/g, '');
});
window.onload = function() {
    var fechaNacField = document.querySelector('input[name="fecha_nac"]');
    var edadField = document.querySelector('input[name="edad_e"]');

    // Calcular la edad cuando se cambia la fecha de nacimiento
    fechaNacField.addEventListener('change', function() {
        var fechaNac = new Date(fechaNacField.value);
        var edad = calcularEdad(fechaNac);
        edadField.value = edad;
    });

    // Calcular la edad inicial
    if (fechaNacField.value) {
        var fechaNac = new Date(fechaNacField.value);
        var edad = calcularEdad(fechaNac);
        edadField.value = edad;
    } else {
        console.log("El valor de fechaNacField no se ha establecido");
    }

    function calcularEdad(fechaNac) {
        var hoy = new Date();
        var edad = hoy.getFullYear() - fechaNac.getFullYear();
        var m = hoy.getMonth() - fechaNac.getMonth();
        if (m < 0 || (m === 0 && hoy.getDate() < fechaNac.getDate())) {
            edad--;
        }
        return edad;
    }
};
	$(document).ready(function(){
        llenarSelectorEstado(document.getElementById("estado"),venezuela);

        $('#estado').val('<?php echo $row['estado']; ?>');
        llenarSelector(municipioSelector,buscarEstado(estadoSelector.value));
        $('#municipio').val('<?php echo $row['municipio']; ?>');
        llenarSelectorMunicipio(parroquiaSelector,buscarMunicipio(estadoSelector.value,municipioSelector.value));
        $('#parroquia').val('<?php echo $row['parroquia']; ?>');
	});		

  	// Obtener los selectores desplegables
  		
  	var estadoSelector = document.getElementById("estado");
 	var municipioSelector = document.getElementById("municipio");
  	var parroquiaSelector = document.getElementById("parroquia");

  	// Agregar un evento para actualizar los municipios cuando se selecciona un estado

    estadoSelector.addEventListener("change", function() {

        llenarSelector(municipioSelector,buscarEstado(estadoSelector.value)); 
    }); 

    // Agregar un evento para actualizar las parroquias cuando se selecciona un municipio
    municipioSelector.addEventListener("change", function() {
        llenarSelectorMunicipio(parroquiaSelector,buscarMunicipio(estadoSelector.value,municipioSelector.value)); 
           
    });     

    // Función para llenar un selector desplegable con opciones
    function llenarSelector(selector, opciones) {
        
        selector.innerHTML = "";
        
        for (var i = 0; i < opciones.length; i++) {
            var opcion = document.createElement("option");
            opcion.value = opciones[i].municipio;
            opcion.text = opciones[i].municipio;
            selector.add(opcion);
        }
    }
    function llenarSelectorMunicipio(selector, opciones) {
        
        selector.innerHTML = "";
        
        for (var i = 0; i < opciones.length; i++) {
            var opcion = document.createElement("option");
            opcion.value = opciones[i];
            opcion.text = opciones[i];
            selector.add(opcion);
        }
    }
    function llenarSelectorEstado(selector, opciones) {
        selector.innerHTML = "";
        for (var i = 0; i < opciones.length; i++) {
            var opcion = document.createElement("option");
            opcion.value = opciones[i].estado;
            opcion.text = opciones[i].estado;
            selector.add(opcion);
        }
    }
    function buscarEstado(estado){  

        for (var i = 0; i < venezuela.length; i++) {
                
            if(venezuela[i].estado == estado){
                return venezuela[i].municipios;
            }   
        }   
    }       
    function buscarMunicipio(estado,municipio){

        var arreglo = buscarEstado(estado);

        for (var i = 0; i < arreglo.length; i++) {
            
            if (arreglo[i].municipio == municipio) {
                
                return arreglo[i].parroquias;
            }   
        }   
    }

	function updateSecciones() {

var gradoSelect = document.getElementById("grado_e");
var seccionSelect = document.getElementById("seccion_e");
var selectedGrado = gradoSelect.value;

// Restaurar todas las opciones
seccionSelect.querySelectorAll("option").forEach(function(option) {
	option.style.display = "block";
});

if (selectedGrado == "Preescolar") {
	// Ocultar las opciones que no sean etapas
	seccionSelect.querySelectorAll("option:not([value^='E'])").forEach(function(option) {
		option.style.display = "none";
	});
} else {
	// Ocultar las opciones que no sean A, B, C o D
	seccionSelect.querySelectorAll("option:not([value='A']):not([value='B']):not([value='C']):not([value='D'])").forEach(function(option) {
		option.style.display = "none";
	});
}
}
	 	
	
</script>  
</body>

</html>
