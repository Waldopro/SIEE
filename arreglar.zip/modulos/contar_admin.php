<?php
include 'verificar_session.php';
include 'rol1.php';
include 'conexion/conndb.php';

$consulta = "SELECT COUNT(*) FROM usuarios WHERE id_cargo = 1 AND activo = 1";
$resultado = mysqli_query($conexion, $consulta);

if ($resultado) {
    $num_administradores = mysqli_fetch_assoc($resultado)['COUNT(*)'];
    echo $num_administradores;
} else {
    echo "Error al contar los administradores: " . mysqli_error($conexion);
}
?>