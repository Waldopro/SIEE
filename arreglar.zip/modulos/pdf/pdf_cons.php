<?php
// Iniciar sesión
include '../verificar_session.php';
require '../conexion/conndb.php';
// Obtener la cédula ingresada por el usuario
$cedula_e = $_GET['cedula_e'];

$stmt = $conexion->prepare("SELECT * FROM estudiante WHERE cedula_e = ?");
$stmt->bind_param("s", $cedula_e);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    die("Error en la consulta: " . mysqli_error($conexion));
}

// Verificar si se encontraron resultados
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $grado_id = $row['grado_id'];  // Obtener el ID del grado

    // Consulta para obtener el nombre del grado
    $stmt_grado = $conexion->prepare("SELECT nombre FROM grados WHERE id = ?");
    $stmt_grado->bind_param("i", $grado_id);
    $stmt_grado->execute();
    $result_grado = $stmt_grado->get_result();

    if (!$result_grado) {
        die("Error en la consulta del grado: " . mysqli_error($conexion));
    }

    if (mysqli_num_rows($result_grado) > 0) {
        $row_grado = mysqli_fetch_assoc($result_grado);
        $current_grado = $row_grado['nombre'];  // Obtener el nombre del grado
    } else {
        $current_grado = "Grado no encontrado";
    }
} else {
    echo "No se encontraron resultados para la cédula ingresada.";
    exit;
}

require_once __DIR__ . '../../../vendor/autoload.php';

$mpdf = new \Mpdf\Mpdf();

// Agregar la cabecera al PDF
$html = '<img src="../../img/cintillo.jpg" width="100%" height="60px">';
$html .= '<h3 style="text-align:center;">República Bolivariana de Venezuela</h3>';
$html .= '<h3 style="text-align:center;">Ministerio del Poder Popular para la Educacion</h3>';
$html .= '<h3 style="text-align:center;">U.E Bolivariana "Eneas Morantes"</h3>';
$html .= '<h3 style="text-align:center;">Yaguaraparo Municipio Cajigal Estado Sucre</h3><br><br><br>';

// Agregar el contenido principal al PDF
$html .= '<p>Quien suscribe, Directora de la Unidad Educativa Bolivariana "Eneas Morante", Código del Plantel Nº 17-006590284, que funciona en la comunidad de la La Chivera, Parroquia Yaguaraparo, Municipio Cajigal Estado Sucre, por medio de la presente hace constar que el (la) alumno (a): ' . $row['nombres_e'] . ' ' . $row['apellidos_e'] . ' titular de la Cédula Nº ' . $row['cedula_e'] . ' de ' . $row['edad_e'] . ' años de edad, ha sido inscrito (a) para cursar el ' . $current_grado . ' grado durante el Año Escolar ' . $row['ins_para'] . '. Constancia que se expide a petición de la parte interesada en Yaguaraparo, a los ' . date('d') . ' días del mes ' . date('m') . ' de ' . date('Y') . '.</p><br><br>';

$html .= '<hr style="border: none; height: 1px; background-color: black; width: 50%;"><br>'; // Línea horizontal con estilo

$html .= '<h3 style="text-align:center;">Atentamente,</h3>';
$html .= '<h3 style="text-align:center;">Olidys Alfonzo</h3>';
$html .= '<h3 style="text-align:center;">Directora</h3>';


$mpdf->WriteHTML($html);

// Generar un nombre de archivo único
$filename = uniqid('constancia_', true) . '.pdf';

// Generar el archivo PDF
$mpdf->Output($filename, 'I'); // I: Enviar al navegador

exit;
?>
