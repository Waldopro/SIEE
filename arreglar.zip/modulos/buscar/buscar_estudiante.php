<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../../css/fontawesome.css">
  <link rel="stylesheet" type="text/css" href="../../css/procesare.css">
  <link rel="stylesheet" type="text/css" href="../../css/inicio.css">
  <link rel="stylesheet" type="text/css" href="../../css/registro_e.css">
  <link rel="stylesheet" type="text/css" href="../../css/procesalogin.css">
  <link rel="stylesheet" href="../../css/footer.css">
  <title>Buscador de Estudiantes</title>
  <script src="../../node_modules/jquery/dist/jquery.min.js"></script>
  <script src="../../js/sweetalert211.js"></script>
</head>
<body oncontextmenu="return false;">
  <?php include('../menu.php') ?>
  <h1 class="h1"><center>Buscador de Estudiantes</center></h1>

  <form id="search-form">
    <div class="contenedor-formularios">
      <div class="formulario">
        <label for="grado">Grado:</label>
        <select name="grado" id="grado">
          <option value="">Seleccione un grado</option>
          <option value="1">Preescolar</option>
          <option value="2">1ro</option>
          <option value="3">2do</option>
          <option value="4">3ro</option>
          <option value="5">4to</option>
          <option value="6">5to</option>
          <option value="7">6to</option>
        </select>

        <label for="seccion">Sección:</label>
        <select name="seccion" id="seccion">
          <option value="">Seleccione una sección</option>
        </select>

        <input class="btn btn-primary" type="submit" value="Buscar">
      </div>
    </div>
  </form>

  <div id="result-container">
    <!-- Aquí se mostrarán los resultados de la búsqueda -->
  </div>

  <div id="print-button" style="display: none;">
    <button onclick="imprimirPDF()">Imprimir PDF</button>
  </div>

  <div class="footer">
    <p>Proyecto <?php echo date('Y'); ?> UPTP CAJIGAL &copy; Todos los derechos reservados</p>
  </div>  
</body>
</html>

<script>
$(document).ready(function() {
  // Manejar el cambio de selección en el campo "grado"
  $("#grado").change(function() {
    var selectedGrado = $(this).val();

    // Realizar una solicitud AJAX para obtener las secciones disponibles para el grado seleccionado
    $.ajax({
      url: "buscar_secciones.php", // Archivo PHP que devolverá las secciones disponibles
      method: "GET",
      data: { grado: selectedGrado },
      dataType: "json",
      success: function(response) {
        // Limpiar las opciones actuales
        $("#seccion").empty();
        $("#seccion").append('<option value="">Seleccione una sección</option>');

        // Agregar las nuevas opciones
        $.each(response, function(index, seccion) {
          $("#seccion").append('<option value="' + seccion.id + '">' + seccion.nombre + '</option>');
        });
      }
    });
  });

  // Escuchar el evento de envío del formulario
  $("#search-form").submit(function(event) {
    event.preventDefault(); // Evitar que el formulario se envíe de forma tradicional

    // Obtener los valores de los campos del formulario
    var seccion = $("#seccion").val();
    var grado = $("#grado").val();

    // Realizar la solicitud AJAX
    $.ajax({
      url: "../procesar/procesar_busqueda.php", // Archivo PHP que realizará la búsqueda en la base de datos
      method: "GET",
      data: { seccion: seccion, grado: grado }, // Datos enviados al servidor
      dataType: "html",
      success: function(response) {
        // Mostrar los resultados en el contenedor de resultados
        $("#result-container").html(response);

        // Mostrar u ocultar el botón de imprimir según si hay resultados
        togglePrintButton($("#result-container").find("table").length > 0);
      }
    });
  });

  // Función para mostrar u ocultar el botón de imprimir
  function togglePrintButton(show) {
    if (show) {
      $("#print-button").show();
    } else {
      $("#print-button").hide();
    }
  }
});

// Función para imprimir el PDF
function imprimirPDF() {
  var seccion = $("#seccion").val();
  var grado = $("#grado").val();

  // Redireccionar a procesar_busqueda.php con los parámetros para imprimir el PDF
  window.location.href = `../procesar/procesar_busqueda.php?seccion=${seccion}&grado=${grado}&imprimir=1`;
}
</script>
