<?php
include '../verificar_session.php';
include '../conexion/conndb.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';

// Obtener la cédula ingresada por el usuario
$cedula_e = $_GET['cedula_e'];

// Consultar la constancia utilizando la cédula como criterio de búsqueda
$sql = "SELECT * FROM estudiante WHERE cedula_e = '$cedula_e'";
$result = mysqli_query($conexion, $sql);

if (!$result) {
    die("Error en la consulta: " . mysqli_error($conexion));
}

// Verificar si se encontraron resultados
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $grado_id = $row['grado_id'];  // Obtener el ID del grado

    // Consulta para obtener el nombre del grado
    $sql_grado = "SELECT nombre FROM grados WHERE id = '$grado_id'";
    $result_grado = mysqli_query($conexion, $sql_grado);

    if (!$result_grado) {
        die("Error en la consulta del grado: " . mysqli_error($conexion));
    }

    if (mysqli_num_rows($result_grado) > 0) {
        $row_grado = mysqli_fetch_assoc($result_grado);
        $current_grado = $row_grado['nombre'];  // Obtener el nombre del grado
    } else {
        $current_grado = "Grado no encontrado";
    }
} else {
    echo "No se encontraron resultados para la cédula ingresada.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Constancia de Inscripción</title>
    <link rel="stylesheet" href="../../css/constancia_e.css">
    <link rel="stylesheet" href="../../css/footer_e.css">
</head>
<body oncontextmenu="return false;">
    <div class="content">
        <img src="../../img/cintillo.jpg" alt="Cabecera de la página" class="header-image">
        <center>
            <h3>Republica Bolivariana de Venezuela<br>
                Ministerio del Poder Popular para la Educacion<br>
                U.E Bolivariana "Eneas Morantes"<br>
                Yaguaraparo Municipio Cajigal Estado Sucre</h3>
        </center>
        <h2>
            <center>Constancia de Inscripción</center>
        </h2>
        <p class="co" style="text-align: center; margin-left: 2.45mm; margin-right: 2.45mm;">
            Quien suscribe, Directora de la Unidad Educativa Bolivariana “Eneas Morante”,
            Código del Plantel Nº 17-006590284, que funciona en la comunidad de la La Chivera, Parroquia Yaguaraparo,
            Municipio Cajigal Estado Sucre, por medio de la presente hace constar que el (la) alumno (a):
            <?php echo $row['nombres_e']; ?> <?php echo $row['apellidos_e']; ?> titular de la Cédula Nº <?php echo $row['cedula_e']; ?>
            de <?php echo $row['edad_e']; ?> años de edad, ha sido inscrito (a) para cursar el <?php echo $current_grado; ?> grado
            durante el Año Escolar <?php echo $row['ins_para']; ?>.
            Constancia que se expide a petición de la parte interesada en Yaguaraparo,
            a los <?php echo date('d'); ?> días del mes <?php echo date('m'); ?> de <?php echo date('Y'); ?>.
        </p><br><br>
        <center>
            <p class="co">
                <center>Atentamente,<br>
                    Olidys Alfonzo<br>
                    Directora</center>
            </p>
        </center>
    </div>

    <div class="button-container">
        <button class="pdf" type="button" onclick="generarPDF('<?php echo $cedula_e; ?>')">Generar PDF</button>
        <button class="volver" onclick="volver()">Volver</button>
    </div>
    <script>
        function generarPDF(cedula_e) {
            window.location.href = "../pdf/pdf_cons.php?cedula_e=" + encodeURIComponent(cedula_e);
        }

        function volver() {
            window.history.back();
        }
    </script>
    <div class="footer">
        <?php include '../footer.php'; ?>
    </div>
</body>
</html>

<?php
// Cerrar la conexión
mysqli_close($conexion);
?>
