<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
include('../verificar_session.php');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Matrícula</title>
    <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../../css/procesarr.css">
    <link rel="stylesheet" type="text/css" href="../../css/inicio.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="../../css/footer.css">
    <script src="../../node_modules/jquery/dist/jquery.min.js"></script>
    <script src="../../lib/datatable/datatables.min.js"></script>
    <script src="../../lib/datatable/dataTables.bootstrap.min.js"></script>
    <script src="../../lib/datatable/jquery.dataTables.min.js"></script>
</head>
<body oncontextmenu="return false;">
    
    <?php include('../menu.php') ?>

    <div class="content">

        <center><h1>Matrícula estudiantíl</h1></center>
        
        <!-- Botón para generar PDF -->
        <div class="text-center mb-3">
            <a class="pdf" href="../pdf/generar_pdf.php">Generar PDF</a>
        </div>
        
        <table id="tabla" class="table table-hover table-condensed">
            <thead>
                <tr>
                    <th>Grado</th>
                    <th>Sección</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Cédula</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include '../conexion/conndb.php';

                // Consulta para obtener la matrícula completa, ordenada alfabéticamente por nombre y apellidos
                $sql = "SELECT estudiante.*, grados.nombre AS nombre_grado, secciones.nombre AS nombre_seccion 
                        FROM estudiante 
                        LEFT JOIN grados ON estudiante.grado_id = grados.id 
                        LEFT JOIN secciones ON estudiante.seccion_id = secciones.id
                        ORDER BY nombre_grado, nombre_seccion, apellidos_e, nombres_e";
                $result = $conexion->query($sql);

                if ($result->num_rows > 0) {
                    $current_grado = "";
                    $current_seccion = "";

                    while ($row = $result->fetch_assoc()) {
                        // Si el grado o la sección son diferentes a los actuales, imprimir un nuevo encabezado
                        if ($row["nombre_grado"] != $current_grado || $row["nombre_seccion"] != $current_seccion) {
                            echo "<tr>";
                            echo "<th colspan='5'>{$row['nombre_grado']} - Sección {$row['nombre_seccion']}</th>";
                            echo "</tr>";
                            $current_grado = $row["nombre_grado"];
                            $current_seccion = $row["nombre_seccion"];
                        }

                        echo "<tr>";
                        echo "<td>{$row['nombre_grado']}</td>";
                        echo "<td>{$row['nombre_seccion']}</td>";
                        echo "<td>{$row['nombres_e']}</td>";
                        echo "<td>{$row['apellidos_e']}</td>";
                        echo "<td>{$row['cedula_e']}</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No se encontraron estudiantes registrados</td></tr>";
                }

                $conexion->close();
                ?>
            </tbody>
        </table>
    </div>
    <div class="footer">
        <p>Proyecto <?php echo date('Y'); ?> UPTP CAJIGAL &copy; Todos los derechos reservados</p>
    </div>
</body>
</html>
