<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
include '../conexion/conndb.php';

$query = "SELECT id, nombre FROM secciones";
$result = $conexion->query($query);

$secciones = [];
while ($row = $result->fetch_assoc()) {
    $secciones[] = $row;
}

// Devolver las secciones en formato JSON
echo json_encode($secciones);

$conexion->close();
?>
