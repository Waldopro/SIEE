<?php
if ($_SESSION["id_cargo"] != 2) {
    echo '<script>';
    echo 'alert("No tiene autorización para acceder a esta página.");';
    echo 'window.location.href = "../login.php";';
    echo '</script>';
    exit();
}
?>