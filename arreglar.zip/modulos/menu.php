<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<div class="navbar">
    <ul>
        <?php if (basename($_SERVER['PHP_SELF']) != 'inicio.php' && basename($_SERVER['PHP_SELF']) != 'iniciousuario.php'): ?>
            <li>
                <?php if (isset($_SESSION['id_cargo']) && $_SESSION['id_cargo'] == '1'): ?>
                    <a href="<?php echo BASE_URL; ?>/inicio.php"><h3>Inicio</h3></a>
                <?php else: ?>
                    <a href="<?php echo BASE_URL; ?>/iniciousuario.php"><h3>Inicio</h3></a>
                <?php endif; ?>
            </li>
        <?php endif; ?>
        <li>
            <a><h3>Gestión</h3></a>
            <ul class="submenu">
                <li><a href="<?php echo BASE_URL; ?>/modulos/registro/registro_representante_estudiante.php"><h3>Registrar estudiante</h3></a></li>
                <?php if (isset($_SESSION['id_cargo']) && $_SESSION['id_cargo'] == '1'): ?>
                    <li><a href="<?php echo BASE_URL; ?>/modulos_nuevos/registrar_d.php"><h3>Registrar docente</h3></a></li>
                    <li><a href="<?php echo BASE_URL; ?>/modulos_nuevos/registrar_aula.php"><h3>Registrar aula</h3></a></li>
                    <li><a href="<?php echo BASE_URL; ?>/modulos/registro/registro_u.php"><h3>Registrar usuario</h3></a></li>
                    <li><a href="<?php echo BASE_URL; ?>/modulos/asignar.php"><h3>Asignar aulas</h3></a></li>
                <?php endif; ?>
            </ul>
        </li>
        <li>
            <a><h3>Listado</h3></a>
            <ul class="submenu">
                <li><a href="<?php echo BASE_URL; ?>/modulos/procesar/procesare.php"><h3>Estudiante</h3></a></li>
                <li><a href="<?php echo BASE_URL; ?>/modulos/procesar/procesarr.php"><h3>Representante</h3></a></li>
                <li><a href="<?php echo BASE_URL; ?>/modulos/procesar/procesarp.php"><h3>Padre o Madre</h3></a></li>
                <?php if (isset($_SESSION['id_cargo']) && $_SESSION['id_cargo'] == '1'): ?>
                    <li><a href="<?php echo BASE_URL; ?>/modulos_nuevos/gestion_docentes.php"><h3>Docentes</h3></a></li>
                    <li><a href="<?php echo BASE_URL; ?>/modulos_nuevos/gestion_aula.php"><h3>Aulas</h3></a></li>
                    <li><a href="<?php echo BASE_URL; ?>/modulos/procesar/procesalogin.php"><h3>Usuarios</h3></a></li>
                <?php endif; ?>
            </ul>
        </li>
        <li>
            <a><h3>Documentos</h3></a>
            <ul class="submenu">
                <li><a href="<?php echo BASE_URL; ?>/modulos/buscar/buscar_matricula.php">Matricula General</a></li>
                <li><a href="<?php echo BASE_URL; ?>/modulos/buscar/buscar_estudiante.php">Matricula por sección</a></li>
                <li><a href="<?php echo BASE_URL; ?>/modulos/constancias/constancia_inscripcion.php">Constancia de Inscripcion</a></li>
                <?php if (isset($_SESSION['id_cargo']) && $_SESSION['id_cargo'] == '1'): ?>
                <li><a href="<?php echo BASE_URL; ?>/modulos_nuevos/estadistica_a.php"><h3>Analisis por año</h3></a></li>
                <?php endif; ?>
            </ul>
        </li>
        <li>
            <a><h3>Ayuda</h3></a>
            <ul class="submenu">
            <?php if (isset($_SESSION['id_cargo']) && $_SESSION['id_cargo'] == '1'): ?>
                <li><a href="<?php echo BASE_URL; ?>/modulos/manual_ua.php">Manual de usuario</a></li>
                <?php endif; ?>
                <?php if (isset($_SESSION['id_cargo']) && $_SESSION['id_cargo'] == '2'): ?>
                <li><a href="<?php echo BASE_URL; ?>/modulos/manual_u.php">Manual de usuario</a></li>
                <?php endif; ?>
                <li><a href="<?php echo BASE_URL; ?>/modulos/acerca.php">Acerca de</a></li>
            </ul>
        </li>
        <li>
            <button class="logout-button" onclick="cerrarSesion()" style="display: inline-block; background-color: #007bff; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Cerrar Sesión</button>
        </li>
    </ul>
</div>

<script src="<?php echo BASE_URL; ?>/js/sweetalert.min.js"></script>
<script type="text/javascript">
    function cerrarSesion() {
        swal({
            title: "¿Estás seguro?",
            text: "¿Deseas cerrar sesión?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willLogout) => {
            if (willLogout) {
                window.location.href = "<?php echo BASE_URL; ?>/logout.php";
            }
        });
    }
</script>
