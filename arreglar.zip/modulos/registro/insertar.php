<?php

function insertarRepresentante($rep, $conexion) {
    // Cambiar valores vacíos a 0 si es necesario
    $rep = array_map(function($key, $value) {
        return ($value === '' && in_array($key, ['edad', 'ser_car', 'codigo_car', 'tipo_cta', 'num_cuenta'])) ? 0 : $value;
    }, array_keys($rep), $rep);

    $sql_rep = 'INSERT INTO representantes (' . implode(', ', array_keys($rep)) . ') VALUES (' . implode(', ', array_fill(0, count($rep), '?')) . ')';
    $stmt = $conexion->prepare($sql_rep);
    $stmt->bind_param(str_repeat('s', count($rep)), ...array_values($rep));

    if (!$stmt->execute()) {
        echo "Error en la consulta: " . $stmt->error;
    } else {
        echo 'Registro exitoso';
    }
    return $conexion->insert_id;
}

function insertarPadreMadre($pad, $conexion) {
    // Cambiar valores vacíos a 0 si es necesario
    $pad = array_map(function($key, $value) {
        return (!is_numeric($value) && $key === 'edad') ? 0 : $value;
    }, array_keys($pad), $pad);

    $sql_pad = 'INSERT INTO padres_madres (' . implode(', ', array_keys($pad)) . ') VALUES (' . implode(', ', array_fill(0, count($pad), '?')) . ')';
    $stmt = $conexion->prepare($sql_pad);
    $stmt->bind_param(str_repeat('s', count($pad)), ...array_values($pad));

    if (!$stmt->execute()) {
        echo "Error en la consulta: " . $stmt->error;
    } else {
        echo 'Registro exitoso';
    }
    return $conexion->insert_id;
}

function insertarEstudiante($est, $conexion) {
    $sql = 'INSERT INTO estudiante (' . implode(', ', array_keys($est)) . ') VALUES (' . implode(', ', array_fill(0, count($est), '?')) . ')';
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param(str_repeat('s', count($est)), ...array_values($est));

    if (!$stmt->execute()) {
        echo "Error en la consulta: " . $stmt->error;
    } else {
        echo 'Registro exitoso';
    }
    return $conexion->insert_id;
}

function insertarPadreMadreConDatosRepresentante($rep, $con) {
    $arreglo = [
        'cedula_p' => $rep['cedula_r'],
        'apellidos_p' => $rep['apellidos'],
        'nombres_p' => $rep['nombres'],
        'fecha_nac_p' => $rep['fecha_nacimiento'],
        'edad' => $rep['edad'],
        'ocupacion_p' => $rep['ocupacion'],
        'tel_p' => $rep['tel_r'],
        'direccion_p' => $rep['direccion_r'],
        'parentesco' => $rep['parentesco']
    ];
    return insertarPadreMadre($arreglo, $con);
}



?>
