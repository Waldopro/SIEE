<?php
include('../verificar_session.php');
include '../rol1.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
?>
<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../../css/procesare.css">
    <link rel="stylesheet" type="text/css" href="../../css/inicio.css">
    <link rel="stylesheet" type="text/css" href="../../css/registro_e.css">
    <link rel="stylesheet" type="text/css" href="../../css/contraseña.css">
    <link rel="stylesheet" href="../../lib/fontawesome-free-6.4.2-web/css/all.css">
    <link rel="stylesheet" href="../../css/footer.css">
    <title>Registro de Usuario</title>
</head>
<body oncontextmenu="return false;">
<?php include('../menu.php') ?>
<script>
        function validarContrasena() {
            var contrasena = document.getElementById('contrasena').value;
            var mensaje = document.getElementById('mensaje-contrasena');
            mensaje.innerHTML = '';

            if (contrasena.length < 5) {
                mensaje.innerHTML += 'La contraseña debe tener al menos 5 caracteres.<br>';
            }
            if (!/\d/.test(contrasena)) {
                mensaje.innerHTML += 'La contraseña debe contener al menos un número.<br>';
            }
            if (!/[!@#$%&*]/.test(contrasena)) {
                mensaje.innerHTML += 'La contraseña debe contener al menos un carácter especial (!@#$%&*).<br>';
            }

            if (mensaje.innerHTML === '') {
                return true;
            } else {
                mensaje.classList.add("error-message");
                return false;
            }
        }
    </script>
<h1 class="h1">
            <center>Registro de Usuario</center>
        </h1>
    <form method="POST" action="../procesar/procesalogin.php">
    <div class="contenedor-formularios">
        
        <div class="formulario">
            <label for="nom_ape">Nombre y Apellido:</label>
            <input type="text" id="nom_ape" name="nom_ape" required placeholder="Ej: Jose Angel">
                <label for="usuario">Nombre de Usuario:</label>
            <input type="text" id="usuario" name="usuario" required placeholder="Ej: FreeArt">
                <label for="usuario">Grado de instrucción:</label>
            <select id="gdo_ins" name="gdo_ins" required>
                <option value="1">Licenciado</option>
                <option value="2">T.S.U</option>
                <option value="2">Bachiller</option>
            </select>

            <label for="contrasena">Contraseña:</label>
            <div class="input-group">
    <input type="password" id="contrasena" name="contrasena" required oninput="validarContrasena()">
    <span class="input-group-text" id="toggle-password">
        <i class="fa fa-eye" aria-hidden="true"></i>
    </span>
    <p id="mensaje-contrasena"></p>
</div>
                <label for="id_cargo">Rol:</label>
            <select id="id_cargo" name="id_cargo" required>
                <option value="1">Administrador</option>
                <option value="2">Usuario</option>
            </select>
                <input type="submit" class="btn btn-primary" onclick="return validarContrasena()" value="Guardar">
            <button id="boton1" style="background-color: blue;color: #f2f2f2;padding: 10px 20px;text-decoration: none; border: none; border-radius: 20px;  cursor: pointer;" onclick="history.back()">Regresar</button>  
        </div>
    </div>
        </form>
        <div class="footer">
    <p>Proyecto <?php echo date('Y'); ?> UPTP CAJIGAL &copy; Todos los derechos reservados</p>
</div>
    <script>
       document.getElementById("toggle-password").addEventListener("click", function(e) {
    var passwordInput = document.getElementById("contrasena");
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        e.target.classList.add("fa-eye-slash");
        e.target.classList.remove("fa-eye");
    } else {
        passwordInput.type = "password";
        e.target.classList.add("fa-eye");
        e.target.classList.remove("fa-eye-slash");
    }
});
        function mostrarConfirmacion(event) {
            event.preventDefault(); // Evitar enviar el formulario de inmediato

            // Obtener los valores de los campos requeridos
            var usuario = document.getElementById('usuario').value;
            var contraseña = document.getElementById('contrasena').value;

            // Verificar si los campos requeridos están llenos
            if (usuario.trim() === '' || contraseña.trim() === '') {
                alert('Por favor, complete todos los campos requeridos.');
            } else {
                if (confirm("Registro realizado con éxito. ¿Desea continuar?")) {
                    // Continuar si se hace clic en Aceptar
                    document.forms[0].submit(); // Enviar el formulario
                } else {
                    // Permanecer en la página si se hace clic en Cancelar
                }
            }
        }
       
    </script>

</body>

</html>