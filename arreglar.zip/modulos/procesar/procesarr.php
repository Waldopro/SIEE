<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
// Verificar si el usuario ha iniciado sesión y si su rol es de "usuario"
include('../verificar_session.php');

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../../node_modules/jquery/dist/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../../css/procesarr.css">
    <link rel="stylesheet" type="text/css" href="../../css/inicio.css">
    <link rel="stylesheet" type="text/css" href="../../css/footer.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/dataTables.bootstrap.min.css">
    <script src="../../lib/datatable/datatables.min.js"></script>
    <script src="../../lib/datatable/dataTables.bootstrap.min.js"></script>
    <script src="../../lib/datatable/jquery.dataTables.min.js"></script>
    
    <title>Representantes</title>

</head>

<body oncontextmenu="return false;">
    
    <?php include('../menu.php') ?>

    <div class="content">  

        <center><h2>Lista de Representantes</h2></center>
        
        <button style="display: inline-block; background-color: #007bff; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;" onclick="history.back()">Volver</button>
        <table id="tabla" class="table table-hover table-condensed">
            <thead>
        <tr>
                <th>ID</th>
                <th>Cédula</th>
                <th>Apellidos</th>
                <th>Nombres</th>
                <th>Fecha de nacimiento</th>
                <th>Edad</th>
                <th class="opciones">Opción</th>            
            </tr>
            </thead>
<tbody>
            <?php
    include '../conexion/conndb.php';   
    // Consultar y mostrar todos los usuarios registrados
    // Realizar la consulta a la base de datos
    $sql = "SELECT id_representante, cedula_r, apellidos, nombres, fecha_nacimiento, edad FROM representante";
$result = $conexion->query($sql);

    // Verificar si se obtuvieron resultados
    if ($result->num_rows > 0) {
        // Mostrar los datos en la tabla
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["id_representante"] . "</td>";
            echo "<td>" . $row["cedula_r"] . "</td>";
            echo "<td>" . $row["apellidos"] . "</td>";
            echo "<td>" . $row["nombres"] . "</td>";
            echo "<td>" . $row["fecha_nacimiento"] . "</td>";
            echo "<td>" . $row["edad"] . "</td>";
            echo "<td>";
            echo "<center> <a class='btn btn-primary a' id='ver-btn' href='#' data-id=" . $row["id_representante"] . "'>Ver</a>  ";
            echo "<a class='btn btn-primary a ' href='../modificar/editarr.php?id=" . $row["id_representante"] . "'>Modificar</a>  ";
            echo "</td>";
            echo "</tr>";
        }
    }else {
        echo "<tr><td colspan='17'>No se encontraron Representantes Registrados</td></tr>";
    }

    // Cerrar la conexión a la base de datos
    $conexion->close();
    ?>
     </tbody>
        </table>
    </div>
    <div class="footer">
    <p>Proyecto <?php echo date('Y'); ?> UPTP CAJIGAL &copy; Todos los derechos reservados</p>
</div>
<script src="../../js/sweetalert.min.js"></script>

    <script type="text/javascript">
        $(document).on('click', '#ver-btn', function(e) {
    e.preventDefault();
    var id = $(this).data('id');
    DatosRepresentante(id);
});
function DatosRepresentante(id) {
    $.ajax({
        url: '../verr.php',
        type: 'GET',
        data: { id: id },
        success: function(response) {
            var datos = JSON.parse(response);
            mostrarAlerta(datos);
        },
        error: function() {
            swal("Error", "Ocurrió un error al obtener los datos del estudiante.", "error");
        }
    });
}
function mostrarAlerta(datos) {
    var texto = 
                "Ocupación: " + (datos.ocupacion || 'N/A') + "\n" +
                "Telefono: " + (datos.tel_r || 'N/A') + "\n" +
                "Dirección: " + (datos.direccion_r || 'N/A') + "\n" +
                "Parentesco: " + (datos.parentesco || 'N/A') + "\n" +
                "Ingreso Mensual: " + (datos.ingreso_mes || 'N/A') + "\n" +
                "Carnet de la patria: " + (datos.carnet_patria || 'N/A') + "\n" +
                "Serial Carnet: " + (datos.ser_car || 'N/A') + "\n" +
                "Código Carnet: " + (datos.codigo_car || 'N/A') + "\n" +
                "Entidad Bancaria: " + (datos.entidad_ban || 'N/A') + "\n" +
                "Tipo de Cuenta: " + (datos.tipo_cta || 'N/A') + "\n" +
                "Numero de Cuenta: " + (datos.num_cuenta || 'N/A') + "\n";

    swal("Datos del representante", texto, "info");
}
    
    $(document).ready(function(){
        $('#tabla').DataTable({
            'language':{
            "lengthMenu": "Mostrar <select class='custom-select custom-select-sm form-control form-control-sm' >\
                            <option value='5' >5</option>\
                            <option value='10'>10</option>\
                            <option value='50'>50</option> \
                            <option value='-1'>Todos</option>\
                            </select > Registros", 
            "zeroRecords":"Nada encontrado - disculpa",
            "info":"mostrando la pagina _PAGE_ de _PAGES_",
            "infoEmpty":"No hay resultados disponibles",
            "infoFiltered":"(filtrado de _MAX_ registros totales)",
            "search":"Buscar",
            "paginate":{
                "next":"siguiente",
                "previous":"Anterior"
            },                    
            "emptyTable":"No hay Registros",                   
        }
        });
    });
    function eliminar(id){
    swal({
        title: "¿Estás seguro?",
        text: "Deseas, eliminar este Representante!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
    .then((willDelete) => {
        if (willDelete) {
            window.location ='../eliminar/eliminarr.php?id='+id;
        }
    });
}

    window.onload = function() {
    var urlParams = new URLSearchParams(window.location.search);
     if (urlParams.has('edicion_exitosa')) {
        swal("¡Éxito!", "El Representante se editó con éxito.", "success");
    } else if (urlParams.has('eliminacion_exitosa')) {
        swal("¡Éxito!", "El Representante se elimino con éxito.", "success");
    }
}

</script>
</body>

</html>