<?php
session_start();
include '../conexion/conndb.php';

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$usuario = $_POST['usuario'];
$contrasena = $_POST['contrasena'];

$usuario = mysqli_real_escape_string($conexion, $usuario);
mysqli_set_charset($conexion, 'utf8');

$consulta = "SELECT * FROM usuarios WHERE usuario='$usuario'";
$resultado = mysqli_query($conexion, $consulta);

if (!$resultado) {
    die("Error en la consulta: " . mysqli_error($conexion));
}

$filas = mysqli_num_rows($resultado);

if ($filas > 0) {
    $fila = mysqli_fetch_assoc($resultado);
    $hash_almacenado = $fila['contrasena'];
    $id_cargo = $fila['id_cargo'];
    $activo = isset($fila['activo']) ? $fila['activo'] : 0;
    $tiempo_cierre_anterior = $fila['tiempo_cierre']; // Obtener el valor de tiempo_cierre

    if ($activo && password_verify($contrasena, $hash_almacenado)) {
        $_SESSION['usuario'] = $usuario;
        $_SESSION['id_cargo'] = $id_cargo;

        // Guardar la última hora de conexión anterior en la sesión
        $_SESSION['tiempo_cierre'] = $tiempo_cierre_anterior;
        // Establecer una cookie para indicar que el usuario ha iniciado sesión
if (!isset($_COOKIE['primer_inicio'])) {
    // La cookie no existe, es el primer inicio de sesión
    setcookie('primer_inicio', '1', time() + (86400 * 30), "/"); // Expira en 30 días (86400 segundos = 1 día)
}

        if ($id_cargo == 1) { //administrador
            header("Location: ../../inicio.php");
            $_SESSION['nombre_usuario'] = $fila['nom_ape']; // Guardar el nombre del usuario en una variable de sesión
            exit();
        } else if ($id_cargo == 2) { //usuario
            header("Location: ../../iniciousuario.php");
            $_SESSION['nombre_usuario'] = $fila['nom_ape']; // Guardar el nombre del usuario en una variable de sesión
            exit();
        }
    } else {
        header("Location: ../../login.php?error=Usuario inactivo o credenciales inválidas.");
        exit();
    }
} else {
    header("Location: ../../login.php?error=Credenciales inválidas");
    exit();
}

?>
