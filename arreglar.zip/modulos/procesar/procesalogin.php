<?php
// Verificar si el usuario ha iniciado sesión y si su rol es de "administrador"
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
include('../verificar_session.php');
include '../rol1.php';
// Conectar a la base de datos
include '../conexion/conndb.php';

mysqli_set_charset($conexion, 'utf8');

// Verificar si se ha enviado el formulario de registro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los valores del formulario
    $nom_ape = $_POST['nom_ape'];
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];
    $id_cargo = $_POST['id_cargo'];
    $gdo_ins = $_POST['gdo_ins'];

    // Hashear la contraseña usando password_hash()
    $hash = password_hash($contrasena, PASSWORD_DEFAULT);

    // Verificar si el usuario ya existe en la base de datos
    $consulta_existencia = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
    $resultado_existencia = mysqli_query($conexion, $consulta_existencia);

    if (mysqli_num_rows($resultado_existencia) > 0) {
        // El usuario ya existe
        echo '<script>alert("El usuario ya existe. Por favor, intente con otro.");</script>';
    } else {
        date_default_timezone_set('America/Caracas');
        $tiempo_inicio = date("Y-m-d H:i:s");
        $tiempo_cierre = date("Y-m-d H:i:s");

        // Preparar la consulta SQL para insertar un nuevo usuario
        $consulta = "INSERT INTO usuarios (nom_ape, usuario, gdo_ins, contrasena, id_cargo, tiempo_inicio, tiempo_cierre) VALUES ('$nom_ape', '$usuario', '$gdo_ins','$hash', '$id_cargo', '$tiempo_inicio', '$tiempo_cierre')";

        // Ejecutar la consulta
if (mysqli_query($conexion, $consulta)) {
    // Inserción exitosa
    header('Location: procesalogin.php?registro_exitoso=true');
    exit;
} else {
    // Error en la inserción
    echo "Error al registrar el usuario: " . mysqli_error($conexion);
}
    }
}

// Realizar la consulta para obtener los usuarios registrados
$consulta = "SELECT * FROM usuarios";
$resultado = mysqli_query($conexion, $consulta);

if (!$resultado) {
    die("Error en la consulta: " . mysqli_error($conexion));
}
?>


<!DOCTYPE html>
<html lang="es">

<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../../css/procesare.css">
    <link rel="stylesheet" type="text/css" href="../../css/inicio.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/dataTables.bootstrap.min.css">
    <script src="../../lib/datatable/datatables.min.js"></script>
    <script src="../../lib/datatable/dataTables.bootstrap.min.js"></script>
    <script src="../../lib/datatable/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="../../css/footer_e.css">
    <script src="../../node_modules/jquery/dist/jquery.min.js"></script>

    <title>Lista de Usuarios</title>

</head>

<body oncontextmenu="return false;">

    <?php include('../menu.php') ?>

    <div class="content">
        <center>
            <h2>Lista de Usuarios</h2>
        </center>

        <button style="display: inline-block; background-color: #007bff; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;" onclick="history.back()">Volver</button>
        <table id="tabla" class="table table-hover table-condensed">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre y Apellido</th>
                    <th>Nombre de Usuario</th>
                    <th>Grado de instrucción</th>
                    <th>Contraseña</th>
                    <th>Rol</th>
                    <th>Estado</th>
                    <th>fecha de conexión</th>
                    <th>ultima conexión</th>
                    <th>Actv/Des</th>
                    <th class="opciones">Opciones Root</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($fila = mysqli_fetch_assoc($resultado)) { ?>
                    <tr>
                        <td><?php echo $fila['id']; ?></td>
                        <td><?php echo $fila['nom_ape']; ?></td>
                        <td><?php echo $fila['usuario']; ?></td>
                        <td><?php echo $fila['gdo_ins']; ?></td>

                        <td>
                            <span class="contrasena" data-id="<?php echo $fila['id']; ?>">*******</span>
                        </td>
                        <td><?= $fila['id_cargo'] == 1 ? 'Administrador' : 'Usuario' ?></td>

                        <td><?php echo (isset($fila['activo']) && $fila['activo']) ? '<span style="color: green;">Activo</span>' : '<span style="color: red;">Inactivo</span>'; ?></td>


                        <td><?php echo date('Y-m-d H:i:s', strtotime($fila['tiempo_inicio'])); ?></td>
                        <td><?php echo date('Y-m-d H:i:s', strtotime($fila['tiempo_cierre'])); ?></td>



                        <td>
    <?php if (isset($fila['activo']) && $fila['activo']) { ?>
        <a class='btn btn-danger a btn-eliminar' href="#" onclick="desactivarUsuario(<?php echo $fila['id']; ?>, <?php echo $fila['id_cargo']; ?>); return false;">Desactivar</a>
    <?php } else { ?>
        <input class='btn btn-primary a ' type="button" value="Activar" onclick="activarUsuario(<?php echo $fila['id']; ?>);">
    <?php } ?>
</td>
                        <td>
                        <?php echo "<center><a class='btn btn-primary a ' href='#' onclick='editarUsuario(" . $fila['id'] . ", " . $fila['id_cargo'] . "); return false;'>Modificar</a>  ";
echo "<a class='btn btn-danger a btn-eliminar' href='#' onclick='eliminarUsuario(" . $fila['id'] . ", " . $fila['id_cargo'] . "); return false;'>Eliminar</a></center>";                           
 ?>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
                            </div>
        <div class="footer">
    <p>Proyecto <?php echo date('Y'); ?> UPTP CAJIGAL &copy; Todos los derechos reservados</p>
</div>
<script src="../../js/sweetalert.min.js"></script>
<script src="../../js/usuarios.js"></script>
</body>

</html>