<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
include '../error.php';
include('../verificar_session.php');

$rol = $_SESSION['id_cargo'] ?? '';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Procesar Formulario estudiante</title>
    <script src="../../node_modules/jquery/dist/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../../css/procesarr.css">
    <link rel="stylesheet" type="text/css" href="../../css/inicio.css">
    <link rel="stylesheet" type="text/css" href="../../css/footer.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="../../lib/datatable/dataTables.bootstrap.min.css">
    <script src="../../lib/datatable/datatables.min.js"></script>
    <script src="../../lib/datatable/dataTables.bootstrap.min.js"></script>
    <script src="../../lib/datatable/jquery.dataTables.min.js"></script>
    <script>
    function redireccionar() {
        var rol = document.querySelector(".a").getAttribute("data-rol");
        if (rol === '1') {
            window.location.href = "../../../inicio.php";
        } else if (rol === '2') {
            window.location.href = "../../../iniciousuario.php";
        } else {
            alert("Rol desconocido o no válido");
        }
    }
    </script>
</head>
<body oncontextmenu="return false;">   
    <?php include('../menu.php')?>
    <div class="content">
        <center><h2 class="">Lista de estudiantes</h2></center>
        <button style="display: inline-block; background-color: #007bff; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;" onclick="history.back()">Volver</button>
        
        <table id="tabla" class="table table-hover table-condensed">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Cedula</th>
                    <th>Apellidos</th>
                    <th>Nombres</th>
                    <th>Representante</th>
                    <th>Padre o Madre</th>
                    <th>Foto</th>
                    <th>Aula</th>
                    <th class="opciones">Opción</th>
                </tr>    
            </thead>
            <tbody>    
            <?php
            include '../conexion/conndb.php';
        
            $sql = "SELECT 
                        e.nombres_e AS nombre, 
                        e.cedula_e AS cedula, 
                        e.id_estudiante AS id, 
                        e.apellidos_e AS apellido, 
                        r.nombres AS representante, 
                        pm.nombres_p AS padre_madre, 
                        f.foto AS foto,
                        e.fotos AS fotos,
                        a.nombre AS aula
                    FROM 
                        estudiante e
                    JOIN 
                        familia f ON e.id_estudiante = f.id_estudiante
                    JOIN 
                        representante r ON r.id_representante = f.id_representante
                    JOIN 
                        padre_madre pm ON pm.id_padre_madre = f.id_padre_madre
                    LEFT JOIN 
                        estudiante_aula ea ON e.id_estudiante = ea.id_estudiante
                    LEFT JOIN 
                        aulas a ON ea.id_aula = a.id_aula";           
             $result = $conexion->query($sql);
            
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id"] . "</td>";
                    echo "<td>" . $row["cedula"] . "</td>";
                    echo "<td>" . $row["apellido"] . "</td>";
                    echo "<td>" . $row["nombre"] . "</td>";
                    echo "<td>" . $row["representante"] . "</td>";
                    echo "<td>" . $row["padre_madre"] . "</td>";
                    echo "<td><img src='../uploads/estudiantes/" . $row["foto"] . "' alt='Foto de " . $row["nombre"] . "' style='width:50px; height:auto; cursor:pointer;' onclick='showOverlay(\"../uploads/estudiantes/" . $row["foto"] . "\")'></td>";                    
                    echo "<td>" . $row["aula"] . "</td>";
                    echo "<td>";
                    echo "<center> <a class='btn btn-primary a' id='ver-btn' href='#' data-id=" . $row["id"] . ">Ver</a>";
                    echo " <a class='btn btn-primary a ' href='../modificar/editare.php?id=" . $row["id"] . "'>Modificar</a>  ";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No se encontraron estudiantes registrados</td></tr>";
            }
            $conexion->close();
            ?>
            </tbody>
        </table>
        <!-- Overlay para la imagen -->
<div class="overlay" id="overlay">
    <span class="close-btn" onclick="closeOverlay()">✖</span>
    <img id="overlay-img" src="" alt="Imagen ampliada">
</div>
    </div>  
    <div class="footer">
        <p>Proyecto <?php echo date('Y'); ?> UPTP CAJIGAL &copy; Todos los derechos reservados</p>
    </div>          
</body>
</html>
<script src="../../js/sweetalert.min.js"></script>

<script type="text/javascript">
    function showOverlay(imgSrc) {
    var overlay = document.getElementById("overlay");
    var overlayImg = document.getElementById("overlay-img");
    overlayImg.src = imgSrc;
    overlay.style.display = "flex";
}

function closeOverlay() {
    document.getElementById("overlay").style.display = "none";
}
$(document).on('click', '#ver-btn', function(e) {
    e.preventDefault();
    var id = $(this).data('id');
    DatosEstudiante(id);
});
function DatosEstudiante(id) {
    $.ajax({
        url: '../datos_estudiante.php',
        type: 'GET',
        data: { id: id },
        success: function(response) {
            var datos = JSON.parse(response);
            mostrarAlerta(datos);
        },
        error: function() {
            swal("Error", "Ocurrió un error al obtener los datos del estudiante.", "error");
        }
    });
}
function mostrarAlerta(datos) {
    var texto = "Fecha de Nacimiento: " + datos.fecha_nac + "\n" +
                "Edad: " + datos.edad_e + "\n" +
                "Sexo: " + datos.sexo + "\n" +
                "Peso: " + datos.peso + "\n" +
                "Talla: " + datos.talla + "\n" +
                "Estado: " + datos.estado + "\n" +
                "Municipio: " + datos.municipio + "\n" +
                "Parroquia: " + datos.parroquia + "\n" +
                "Lugar de Nacimiento: " + datos.lugar_nac + "\n" +
                "Dirección: " + datos.direccion_e + "\n" +
                "Teléfono: " + datos.tel_e + "\n" +
                "Posee Canaima: " + datos.posee_can + "\n" +
                "Serial de la Canaima: " + (datos.ser_can || 'N/A') + "\n" +
                "Becado: " + datos.becado + "\n" +
                "Grado: " + datos.nombre_grado + "\n" +  // Mostrar el nombre del grado
                "Sección: " + datos.nombre_seccion + "\n" + // Mostrar el nombre de la sección
                "Inscrito para el año: " + datos.ins_para + "\n" +
                "Tipo de Inscripción: " + datos.tipo_ins + "\n" +
                "Copias de Cedula: " + datos.copias_ci + "\n" +
                "Partida de Nacimiento Copia: " + datos.partida_nac_co + "\n" +
                "Fotos: " + datos.fotos + "\n" +
                "Historia Escolar: " + datos.historia_esc + "\n" +
                "Certificado de Promoción: " + datos.cert_prom + "\n" +
                "Tarjeta de Vacunación: " + datos.tarj_vac + "\n" +
                "Constancia de Conducta: " + datos.cons_conduc + "\n" +
                "Constancia de Retiro: " + datos.cons_retiro + "\n" +
                "Certificación de Notas: " + datos.cert_notas;
    swal("Datos del estudiante", texto, "info");

}
$(document).ready(function(){
    $('#tabla').DataTable({
        'language':{
        "lengthMenu": "Mostrar <select class='custom-select custom-select-sm form-control form-control-sm' >\
                        <option value='5' >5</option>\
                        <option value='10'>10</option>\
                        <option value='50'>50</option> \
                        <option value='-1'>Todos</option>\
                        </select > Registros", 
        "zeroRecords":"Nada encontrado - disculpa",
        "info":"mostrando la pagina _PAGE_ de _PAGES_",
        "infoEmpty":"No hay resultados disponibles",
        "infoFiltered":"(filtrado de _MAX_ registros totales)",
        "search":"Buscar",
        "paginate":{
            "next":"siguiente",
            "previous":"Anterior"
        },                    
        "emptyTable":"No hay Registros",                   
    }
    });
});
function eliminar(id){
    swal({
        title: "¿Estás seguro?",
        text: "Deseas, eliminar este estudiante!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
    .then((willDelete) => {
        if (willDelete) {
            window.location ='../eliminar/eliminare.php?id='+id;
        }
    });
}
window.onload = function() {
    var urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('registro_exitoso')) {
        swal("¡Éxito!", "El estudiante se registró con éxito.", "success");
    } else if (urlParams.has('edicion_exitosa')) {
        swal("¡Éxito!", "El estudiante se editó con éxito.", "success");
    } else if (urlParams.has('eliminacion_exitosa')) {
        swal("¡Éxito!", "El Estudiante se elimino con éxito.", "success");
    }
}
</script>
