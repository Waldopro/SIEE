<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
// Iniciar sesión
include '../verificar_session.php';

// Conexión a la base de datos (reemplaza con tus credenciales)
include '../conexion/conndb.php';

// Validar si seccion y grado están definidos en $_GET
if (isset($_GET['seccion']) && isset($_GET['grado'])) {
    // Obtener los valores enviados desde el formulario
    $seccion = $_GET['seccion'];
    $grado = $_GET['grado'];

    // Consulta para buscar los estudiantes por sección y grado
    $sql = "SELECT id_estudiante, nombres_e, apellidos_e, edad_e, seccion_id, grado_id FROM estudiante WHERE seccion_id = ? AND grado_id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("ii", $seccion, $grado);
    $stmt->execute();
    $result = $stmt->get_result();

    echo '<div class="content">';
    // Construir la tabla con los resultados
    if ($result->num_rows > 0) {
        echo '<table id="tabla" class="table table-hover table-condensed">';
        echo '<thead><tr><th>ID</th><th>Nombres</th><th>Apellidos</th><th>Edad</th><th>Sección</th><th>Grado</th></tr></thead>';
        echo '<tbody>';
        while ($fila = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $fila['id_estudiante'] . '</td>';
            echo '<td>' . $fila['nombres_e'] . '</td>';
            echo '<td>' . $fila['apellidos_e'] . '</td>';
            echo '<td>' . $fila['edad_e'] . '</td>';
            echo '<td>' . $fila['seccion_id'] . '</td>';
            echo '<td>' . $fila['grado_id'] . '</td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
    } else {
        echo 'No se encontraron estudiantes.';
    }
    echo '</div>';

    // Verificar si se envió el parámetro "imprimir" y si hay resultados para generar el PDF
    if (isset($_GET['imprimir']) && $_GET['imprimir'] === "1" && $result->num_rows > 0) {

        // Incluir la biblioteca mPDF
        require_once __DIR__ . '/../../vendor/autoload.php';

        // Crear una nueva instancia de mPDF
        $mpdf = new \Mpdf\Mpdf();

        // Crear el contenido del PDF
        $html = '<img src="../../img/cintillo.jpg" width="100%" height="60px">';
        $html .= '<h3 style="text-align:center;">República Bolivariana de Venezuela</h3>';
        $html .= '<h3 style="text-align:center;">Ministerio del Poder Popular para la Educación</h3>';
        $html .= '<h3 style="text-align:center;">U.E Bolivariana "Eneas Morantes"</h3>';
        $html .= '<h3 style="text-align:center;">Yaguaraparo Municipio Cajigal Estado Sucre</h3><br><br>';
        $html .= '<h1 style="text-align:center;">Lista de Estudiantes</h1><br><br>';
        $html .= '<table border="1" style="width:100%">
                      <tr>
                          <th>ID</th>
                          <th>Nombres</th>
                          <th>Apellidos</th>
                          <th>Edad</th>
                          <th>Grado</th>
                          <th>Sección</th>
                      </tr>';

        while ($fila = $result->fetch_assoc()) {
            $html .= '<tr>
                        <td>' . $fila['id_estudiante'] . '</td>
                        <td>' . $fila['nombres_e'] . '</td>
                        <td>' . $fila['apellidos_e'] . '</td>
                        <td>' . $fila['edad_e'] . '</td>
                        <td>' . $fila['grado_id'] . '</td>
                        <td>' . $fila['seccion_id'] . '</td>
                      </tr>';
        }

        $html .= '</table>';

        // Escribir el contenido HTML en el PDF
        $mpdf->WriteHTML($html);

        // Salida del PDF al navegador
        $mpdf->Output();
    }

} else {
    echo 'Parámetros "seccion" y "grado" no definidos.';
}

// Cerrar la conexión a la base de datos
$conexion->close();
?>
