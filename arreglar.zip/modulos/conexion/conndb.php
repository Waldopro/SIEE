<?php
$servername = "localhost";
$username = "root";
$password = "1704";
$dbname = "escuela";

// Crear conexión
$conexion = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

?>
