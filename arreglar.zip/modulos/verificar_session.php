<?php 	 
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
session_start();

if (!isset($_SESSION["usuario"])) {
    echo '<script>';
    echo 'alert("No tiene autorización. Será redireccionado al inicio de sesión.");';
    echo 'window.location.href = "' . BASE_URL . '/login.php";';
    echo '</script>';
    exit();
}

?>