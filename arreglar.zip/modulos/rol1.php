<?php
if ($_SESSION["id_cargo"] != 1) {
    echo '<script>';
    echo 'alert("No tiene autorización. Será redireccionado al inicio de sesión.");';
    echo 'window.location.href = "../login.php";';
    echo '</script>';
    exit();
}	
?>