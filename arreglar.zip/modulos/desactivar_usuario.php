<?php include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Desactivar Usuario</title>
</head>
<body>
<?php
include 'verificar_session.php';
include 'rol1.php';

// Obtener el ID del usuario a desactivar
$id = $_GET['id'];

// Configuración de la conexión a la base de datos
include 'conexion/conndb.php';
// Crear la conexión
// Obtener el cargo del usuario que se va a desactivar
$consulta_cargo = "SELECT id_cargo FROM usuarios WHERE id = '$id'";
$resultado_cargo = mysqli_query($conexion, $consulta_cargo);
if (!$resultado_cargo) {
    die("Error en la consulta: " . mysqli_error($conexion));
}

$fila_cargo = mysqli_fetch_assoc($resultado_cargo);
$id_cargo_usuario = $fila_cargo['id_cargo'];

// Realizar las acciones necesarias para desactivar al usuario seleccionado
$sql = "UPDATE usuarios SET activo = 0 WHERE id = '$id'";

// Ejecutar la consulta
if (mysqli_query($conexion, $sql)) {
    // La consulta se ejecutó con éxito

    // Redireccionar a la página de usuarios registrados después de desactivar al usuario
    header("Location: ../modulos/procesar/procesalogin.php");
    exit();
} else {
    // Hubo un error al ejecutar la consulta
    echo "Error: " . mysqli_error($conexion);
}


// Cerrar la conexión a la base de datos
mysqli_close($conexion);
?>
<!-- Botón para volver atrás -->
<button onclick="goBack()">Volver Atrás</button>

<!-- Script JavaScript para la función goBack() -->
<script>
function goBack() {
    window.history.go(-1);
}
</script>

</body>
</html>