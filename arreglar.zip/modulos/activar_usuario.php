<?php
// Obtener el ID del usuario a activar
$id = $_GET['id'];
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
include 'verificar_session.php';
include 'rol1.php';
// Configuración de la conexión a la base de datos
include 'conexion/conndb.php';


// Realizar las acciones necesarias para activar al usuario
$sql = "UPDATE usuarios SET activo = 1 WHERE id = '$id'";

if (mysqli_query($conexion, $sql)) {
    echo '<script>alert("Estado del usuario actualizado correctamente.");</script>';
     // Redireccionar a la página de usuarios registrados después de activar al usuario
     header("Location: ../modulos/procesar/procesalogin.php");
     exit();
} else {
    echo "Error al actualizar el estado del usuario: " . mysqli_error($conexion);  
}

// Cerrar la conexión a la base de datos
mysqli_close($conexion);
?>

