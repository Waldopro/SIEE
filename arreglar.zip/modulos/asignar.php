<?php
include 'conexion/conndb.php';
// Consulta para obtener la lista de estudiantes
$query = "SELECT id_estudiante, nombres_e, apellidos_e, grado_id FROM estudiante";
$result = $conexion->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Estudiantes</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.7/dist/sweetalert2.min.css">
</head>
<body>
    <h2>Listado de Estudiantes</h2>
    <table border="1">
        <thead>
            <tr>
                <th>Nombres</th>
                <th>Apellidos</th>
                <th>Grado</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['nombres_e']; ?></td>
                    <td><?php echo $row['apellidos_e']; ?></td>
                    <td><?php echo $row['grado_id']; ?></td>
                    <td>
                        <button onclick="asignarAula(<?php echo $row['id_estudiante']; ?>)">Asignar Aula</button>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    function asignarAula(id_estudiante) {
        Swal.fire({
            title: 'Asignar Aula',
            input: 'select',
            inputOptions: {
                <?php
                // Obtener las aulas disponibles
                $aulas_query = "SELECT id_aula, nombre FROM aulas WHERE capacidad < 25"; // Por ejemplo, con capacidad límite de 25
                $aulas_result = $conexion->query($aulas_query);

                $aula_options = [];
                while ($aula_row = $aulas_result->fetch_assoc()) {
                    echo $aula_row['id_aula'] . ":'" . $aula_row['nombre'] . "',";
                }
                ?>
        },
            inputPlaceholder: 'Selecciona una aula',
            showCancelButton: true,
            inputValidator: (value) => {
                if (!value) {
                    return 'Necesitas seleccionar un aula!'
                } else {
                    window.location.href = "asignar_aula.php?id_estudiante=" + id_estudiante + "&id_aula=" + value;
                }
            }
        });
    }
    </script>
</body>
</html>

<?php
$conexion->close();
?>
