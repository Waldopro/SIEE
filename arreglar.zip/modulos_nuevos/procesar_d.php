<?php
// Verificar si se han enviado los datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Incluir el archivo de conexión a la base de datos
    include '../modulos/conexion/conndb.php';

    // Obtener los datos del formulario
    $cedula = $_POST["cedula"];
    $nombres = $_POST["nombres"];
    $apellidos = $_POST["apellidos"];
    $gdo_ins = $_POST["gdo_ins"];
    $aula_id = $_POST["aula_id"];

    // Validar que la cédula no esté duplicada
    $consulta = "SELECT COUNT(*) AS total FROM docentes WHERE cedula = '$cedula'";
    $resultado = $conexion->query($consulta);
    $fila = $resultado->fetch_assoc();
    if ($fila["total"] > 0) {
        // Mostrar mensaje de error y redireccionar al formulario
        echo "La cédula ya está registrada. Por favor, ingresa una cédula diferente.";
        header("Location: registrar_d.php");
        exit();
    }

    // Realizar la inserción en la base de datos
    $consulta = "INSERT INTO docentes (cedula, nombres, apellidos, gdo_ins, aula_id) 
                 VALUES ('$cedula', '$nombres', '$apellidos', '$gdo_ins', '$aula_id')";
    if ($conexion->query($consulta) === TRUE) {
        // Redirigir al usuario a una página de éxito
        header("Location: gestion_docentes.php");
        exit();
    } else {
        // Manejar el error de la base de datos
        echo "Error en la base de datos: " . $conexion->error;
    }

    // Cerrar la conexión a la base de datos
    $conexion->close();
} else {
    // Redirigir al usuario si intenta acceder directamente a este script
    header("Location: registrar_d.php");
    exit();
}
?>
