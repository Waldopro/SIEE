<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
include ('../modulos/verificar_session.php');
include ('../modulos/rol1.php');
?>
<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../css/procesare.css">
    <link rel="stylesheet" type="text/css" href="../css/inicio.css">
    <link rel="stylesheet" type="text/css" href="../css/registro_e.css">
    <link rel="stylesheet" type="text/css" href="../css/contraseña.css">
    <link rel="stylesheet" type="text/css" href="../css/footer.css">
    <link rel="stylesheet" href="../lib/fontawesome-free-6.4.2-web/css/all.css">
    <title>Registro de Docente</title>
</head>
<body oncontextmenu="return false;">
<?php include('../modulos/menu.php') ?>

<h1 class="h1">
            <center>Registro de Docente</center>
        </h1>
    <form method="POST" action="procesar_d.php">
    <div class="contenedor-formularios">
        
        <div class="formulario"> 
            <label for="cedula">Cedula:</label>
            <input type="number" name="cedula" id="cedula" required placeholder="14105489">
            <label for="nombres">Nombres:</label>
            <input type="text" id="nombres" name="nombres" required placeholder="Ej: Jose">
                <label for="apellidos">Apellidos:</label>
            <input type="text" id="apellidos" name="apellidos" required placeholder="Ej: Granado">
                <label for="gdo_ins">Grado de instrucción:</label>
            <select id="gdo_ins" name="gdo_ins" required>
                <option value="1">Grado 1</option>
                <option value="2">Grado 2</option>
                <option value="3">Grado 3</option>
                <option value="4">Grado 4</option>
                <option value="5">Grado 5</option>
                <option value="6">Grado 6</option>
                <option value="7">Grado 7</option>
            </select>
            <label for="aula">Asignar aula</label>
<select id="aula" name="aula_id" required>
    <?php
    //incluir base de datos
    include '../modulos/conexion/conndb.php';
    // Consultar las aulas disponibles
    $consulta_aulas = "SELECT id_aula, nombre FROM aulas";
    $result_aulas = $conexion->query($consulta_aulas);

    // Mostrar las opciones de aulas en un select
    while ($fila_aula = $result_aulas->fetch_assoc()) {
        echo "<option value='" . $fila_aula['id_aula'] . "'>" . $fila_aula['nombre'] . "</option>";
    }
    ?>
</select>
                <input type="submit" class="btn btn-primary"value="Guardar">
            <button id="boton1" style="background-color: blue;color: #f2f2f2;padding: 10px 20px;text-decoration: none; border: none; border-radius: 20px;  cursor: pointer;" onclick="history.back()">Regresar</button>  
        </div>
    </div>
        </form>
        <div class="footer">
    <p>Proyecto <?php echo date('Y'); ?> UPTP CAJIGAL &copy; Todos los derechos reservados</p>
</div>
    

</body>

</html>