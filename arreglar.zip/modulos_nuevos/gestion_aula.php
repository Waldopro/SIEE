<? 
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
include ('../modulos/verificar_session.php');
include ('../modulos/rol1.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de aulas</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../css/procesare.css">
    <link rel="stylesheet" type="text/css" href="../css/inicio.css">
    <link rel="stylesheet" type="text/css" href="../lib/datatable/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../lib/datatable/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="../lib/datatable/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="../css/footer.css">
    <script src="../node_modules/jquery/dist/jquery.min.js"></script>
    <script src="../lib/datatable/datatables.min.js"></script>
    <script src="../lib/datatable/dataTables.bootstrap.min.js"></script>
    <script src="../lib/datatable/jquery.dataTables.min.js"></script>
</head>
<body oncontextmenu="return false;">   
    <?php include('../modulos/menu.php')?>
        
    <div class="content">
    <h2><center>Lista de Aulas</center></h2>

    <button style="display: inline-block; background-color: #007bff; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;" onclick="history.back()">Volver</button>
    <table id="tabla" class="table table-hover table-condensed" >
    <thead>

  <tr>
    <th>ID</th>
    <th>Aula</th>
    <th>Grado</th>
    <th>Sección</th>
    <th>Capacidad</th>
  </tr>
  </thead>
  <tbody>    

  <?php
  // Conexión a la base de datos y consulta de las aulas
  include '../modulos/conexion/conndb.php';
  $consulta = "SELECT * FROM vista_aulas";
  $resultado = $conexion->query($consulta);

// Verificar si se encontraron aulas registradas
if ($resultado->num_rows > 0) {
    // Mostrar las aulas en la tabla
    while ($fila = $resultado->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $fila['id_aula'] . "</td>";
        echo "<td>" . $fila['nombre'] . "</td>";
        echo "<td>" . $fila['grado'] . "</td>";
        echo "<td>" . $fila['seccion'] . "</td>";
        echo "<td>" . $fila['capacidad'] . "</td>";
        
        echo "</tr>";
    }
} else {
    // Mostrar mensaje si no se encontraron aulas registradas
    echo "<tr><td colspan='5'>No se encontraron aulas registradas</td></tr>";
}

  // Cerrar la conexión a la base de datos
  $conexion->close();
  ?>

</tbody>
        </table>
            
    </div>  
    <div class="footer">
<?php include '../modulos/footer.php'; ?>
  </div>   
</body>
</html>