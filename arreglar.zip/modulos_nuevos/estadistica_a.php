<?php
require 'funcion_e.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
include ('../modulos/verificar_session.php');
include ('../modulos/rol1.php');

// Asegúrate de que esta línea esté presente y correcta
$estadisticas = obtenerEstadisticas();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Estadísticas de Inscripción de Estudiantes</title>
    <script src="../js/chart.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../css/procesare.css">
    <link rel="stylesheet" type="text/css" href="../css/estadistica.css">
    <link rel="stylesheet" type="text/css" href="../css/inicio.css">
    <link rel="stylesheet" type="text/css" href="../lib/datatable/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../lib/datatable/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="../lib/datatable/dataTables.bootstrap.min.css">
    <script src="../node_modules/jquery/dist/jquery.min.js"></script>
    <script src="../lib/datatable/datatables.min.js"></script>
    <script src="../lib/datatable/dataTables.bootstrap.min.js"></script>
    <script src="../lib/datatable/jquery.dataTables.min.js"></script>
    <script src="../js/tiempo_sesion.js"></script>
    <link rel="stylesheet" href="../css/footer.css">
    
</head>
<body oncontextmenu="return false;">   
    <?php include('../modulos/menu.php')?>
        
    <div class="content">
        <h1><center>Estadísticas de Inscripción de Estudiantes</center></h1>
        <br>
        <button class="btn btn-primary" onclick="history.back()">Volver</button>
        <button class="pdf-button" onclick="descargarPDF()"><i class="fas fa-file-pdf"></i> Generar PDF</button>
        <button class="csv-button" onclick="descargarCSV()"><i class="fas fa-file-csv"></i> Descargar CSV</button>
        
        <div class="table-container">
            <table id="tabla" class="table table-hover table-condensed table-striped">
                <thead>
                    <tr>
                        <th>Año</th>
                        <th>Grado</th>
                        <th>Total Estudiantes</th>
                        <th>Total Masculinos</th>
                        <th>Total Femeninos</th>
                        <th>Total Nuevos</th>
                        <th>Total Regulares</th>
                        <th>Total Repitientes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($estadisticas)): ?>
                        <?php foreach ($estadisticas as $estadistica): ?>
                            <tr>
                                <td><?php echo $estadistica['año']; ?></td>
                                <td><?php echo $estadistica['grados']; ?></td>
                                <td><?php echo $estadistica['total_estudiantes']; ?></td>
                                <td><?php echo $estadistica['total_masculinos']; ?></td>
                                <td><?php echo $estadistica['total_femeninos']; ?></td>
                                <td><?php echo $estadistica['total_nuevos']; ?></td>
                                <td><?php echo $estadistica['total_regulares']; ?></td>
                                <td><?php echo $estadistica['total_repitientes']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center">No hay datos disponibles</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <canvas id="graficaBarras" width="1600" height="300"></canvas>
    </div>  
    <div class="footer">
        <?php include '../modulos/footer.php'; ?>
    </div>    
    <script>
        var datosEstadisticas = <?php echo json_encode($estadisticas); ?>;
        var años = [];
        var grados = [];
        var totalEstudiantes = {};

        datosEstadisticas.forEach(function (item) {
            if (!años.includes(item.año)) {
                años.push(item.año);
            }
            if (!grados.includes(item.grados)) {
                grados.push(item.grados);
            }
        });

        grados.forEach(function(grado) {
            totalEstudiantes[grado] = Array(años.length).fill(0);
        });

        datosEstadisticas.forEach(function (item) {
            var añoIndex = años.indexOf(item.año);
            totalEstudiantes[item.grados][añoIndex] = item.total_estudiantes;
        });

        var colores = [
            'rgba(54, 162, 235, 0.5)',
            'rgba(75, 192, 192, 0.5)',
            'rgba(255, 206, 86, 0.5)',
            'rgba(153, 102, 255, 0.5)',
            'rgba(255, 159, 64, 0.5)',
            'rgba(255, 99, 132, 0.5)'
        ];

        var bordeColores = [
            'rgba(54, 162, 235, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)',
            'rgba(255, 99, 132, 1)'
        ];

        var datasets = años.map(function (año, index) {
            return {
                label: 'Año ' + año,
                data: grados.map(function(grado) {
                    return totalEstudiantes[grado][index];
                }),
                backgroundColor: colores[index % colores.length],
                borderColor: bordeColores[index % bordeColores.length],
                borderWidth: 1
            };
        });

        var ctx = document.getElementById('graficaBarras').getContext('2d');
        var graficaBarras = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: grados,
                datasets: datasets
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                var label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += context.raw;
                                return label;
                            }
                        }
                    }
                }
            }
        });

        function descargarPDF() {
            var canvas = document.getElementById('graficaBarras');
            var imgData = canvas.toDataURL('image/png');
            
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'pdf_e.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.responseType = 'blob';
            xhr.onload = function () {
                if (xhr.status === 200) {
                    var link = document.createElement('a');
                    link.href = window.URL.createObjectURL(xhr.response);
                    link.download = 'estadistica_estudiantes.pdf';
                    link.click();
                }
            };
            xhr.send('imgData=' + encodeURIComponent(imgData));
        }

        function descargarCSV() {
            var csv = 'Año,Grado,Total Estudiantes,Total Masculinos,Total Femeninos,Total Nuevos,Total Regulares,Total Repitientes\n';
            datosEstadisticas.forEach(function(row) {
                csv += row.año + ',' + row.grados + ',' + row.total_estudiantes + ',' + row.total_masculinos + ',' + row.total_femeninos + ',' + row.total_nuevos + ',' + row.total_regulares + ',' + row.total_repitientes + '\n';
            });

            var hiddenElement = document.createElement('a');
            hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
            hiddenElement.target = '_blank';
            hiddenElement.download = 'estadistica_estudiantes.csv';
            hiddenElement.click();
        }
    </script>
</body>
</html>
