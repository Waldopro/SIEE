<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
include '../modulos/conexion/conndb.php';
// Verificar si el usuario ha iniciado sesión y si su rol es de "usuario"
include '../modulos/verificar_session.php';

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $cedula = $_POST['cedula'];
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $gdo_ins = $_POST['gdo_ins'];
    $aula_id = $_POST['aula_id'];

    $sql = "UPDATE docentes SET 
    cedula='$cedula',
    nombres='$nombres',
    apellidos='$apellidos',
    gdo_ins='$gdo_ins',
    aula_id='$aula_id'
    WHERE id='$id'";

    if ($conexion->query($sql) === TRUE) {
        header("Location: gestion_docentes.php?edicion_exitosa=true");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conexion->error;
    }
}

// Obtener el valor de id de la URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM docentes WHERE id='$id'";
    $result = $conexion->query($sql);
    $row = $result->fetch_assoc();
    $conexion->close();
} else {
    echo "No se recibió el parámetro 'id' en la URL";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Docente</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../css/inicio.css">
    <link rel="stylesheet" type="text/css" href="../css/editare.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" type="text/css" href="../css/registro_e.css">
</head>

<body oncontextmenu="return false;">
<?php include('../modulos/menu.php') ?>
    <h1 class="h1">
        <center>Editar Docente</center>
    </h1>
    <form method="POST" action="">
    <div class="contenedor-formularios">
        <div class="formulario">
        <input type="hidden" name="id" value="<?php echo $id; ?>" readonly>

        <label>Cédula:</label>
        <input type="text" name="cedula" maxlength="8" value="<?php echo $row['cedula']; ?>" required><br><br>

        <label>Nombres:</label>
        <input type="text" name="nombres" value="<?php echo $row['nombres']; ?>" required><br><br>

        <label>Apellidos:</label>
        <input type="text" name="apellidos" value="<?php echo $row['apellidos']; ?>" required><br><br>

        <label>Grado de Instrucción:</label>
        <select id="gdo_ins" name="gdo_ins">
            <option value="grado 1" <?php if ($row['gdo_ins'] == "grado 1") echo "selected"; ?>>Grado 1</option>
            <option value="grado 2" <?php if ($row['gdo_ins'] == "grado 2") echo "selected"; ?>>Grado 2</option>
            <option value="grado 3" <?php if ($row['gdo_ins'] == "grado 3") echo "selected"; ?>>Grado 3</option>
            <option value="grado 4" <?php if ($row['gdo_ins'] == "grado 4") echo "selected"; ?>>Grado 4</option>
            <option value="grado 5" <?php if ($row['gdo_ins'] == "grado 5") echo "selected"; ?>>Grado 5</option>
            <option value="grado 6" <?php if ($row['gdo_ins'] == "grado 6") echo "selected"; ?>>Grado 6</option>
            <option value="grado 7" <?php if ($row['gdo_ins'] == "grado 7") echo "selected"; ?>>Grado 7</option>
        </select><br><br>

        <label>Aula ID:</label>
        <input type="number" name="aula_id" value="<?php echo $row['aula_id']; ?>"><br><br>

        <input class="btn btn-primary" type="submit" name="update" value="Actualizar">
        <a href="gestion_docentes.php" class="back-button">Volver</a>
        </div>
    </div>
    </form>
    <div class="footer">
        <p>Proyecto <?php echo date('Y'); ?> UPTP CAJIGAL &copy; Todos los derechos reservados</p>
    </div>
</body>
</html>
