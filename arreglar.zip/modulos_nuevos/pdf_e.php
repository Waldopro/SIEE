<?php
require_once 'tcpdf/tcpdf.php';
require 'funcion_e.php';

$estadisticas = obtenerEstadisticas();
$imgData = $_POST['imgData'];

// Crear una instancia de TCPDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Información del documento
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Tu Nombre');
$pdf->SetTitle('Estadísticas de Inscripción de Estudiantes');
$pdf->SetSubject('Reporte de Estadísticas');

// Configuración de la cabecera y pie de página
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Configuración de la fuente
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
$pdf->SetFont('helvetica', '', 12);

// Añadir una página
$pdf->AddPage();

// Añadir la imagen del cintillo
$pdf->Image('../img/cintillo.jpg', 10, 10, 190, 20, 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);

// Espaciado después de la imagen del cintillo
$pdf->Ln(25);

$html = '
<h3 style="text-align:center;">República Bolivariana de Venezuela</h3>
<h3 style="text-align:center;">Ministerio del Poder Popular para la Educación</h3>
<h3 style="text-align:center;">U.E Bolivariana "Eneas Morantes"</h3>
<h3 style="text-align:center;">Yaguaraparo Municipio Cajigal Estado Sucre</h3><br><br><br>
<h1 style="text-align:center;">Estadísticas de Inscripción de Estudiantes</h1>
<table border="1" cellpadding="5">
    <thead>
        <tr>
            <th>Año</th>
            <th>Grado</th>
            <th>Total Estudiantes</th>
            <th>Total Masculinos</th>
            <th>Total Femeninos</th>
            <th>Total Nuevos</th>
            <th>Total Regulares</th>
            <th>Total Repitientes</th>
        </tr>
    </thead>
    <tbody>';

foreach ($estadisticas as $estadistica) {
    $html .= '
    <tr>
        <td>' . htmlspecialchars($estadistica['año']) . '</td>
        <td>' . htmlspecialchars($estadistica['grados']) . '</td>
        <td>' . htmlspecialchars($estadistica['total_estudiantes']) . '</td>
        <td>' . htmlspecialchars($estadistica['total_masculinos']) . '</td>
        <td>' . htmlspecialchars($estadistica['total_femeninos']) . '</td>
        <td>' . htmlspecialchars($estadistica['total_nuevos']) . '</td>
        <td>' . htmlspecialchars($estadistica['total_regulares']) . '</td>
        <td>' . htmlspecialchars($estadistica['total_repitientes']) . '</td>
    </tr>';
}

$html .= '
    </tbody>
</table>';

// Escribir el contenido HTML al PDF
$pdf->writeHTML($html, true, false, true, false, '');

// Verificar si los datos de la imagen están presentes y correctamente codificados
if (!empty($imgData)) {
    list($type, $data) = explode(';', $imgData);
    list(, $data)      = explode(',', $data);
    $data = base64_decode($data);

    // Escribir la imagen de la gráfica al PDF
    if ($data !== false) {
        $pdf->Image('@' . $data, 15, 200, 180, 90, 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
    } else {
        // Mostrar un mensaje de error si la decodificación falla
        $pdf->Cell(0, 10, 'Error al decodificar la imagen.', 1, 1, 'C');
    }
} else {
    // Mostrar un mensaje de error si los datos de la imagen están vacíos
    $pdf->Cell(0, 10, 'No se recibieron datos de la imagen.', 1, 1, 'C');
}

// Salida del PDF (D: descargar, I: mostrar en navegador)
$pdf->Output('estadisticas_estudiantes.pdf', 'I');
?>
