<?php
require '../modulos/conexion/conndb.php';

function obtenerEstadisticas() {
  global $conexion;

    $sql = "
        SELECT
            e.ins_para AS año,
            g.nombre AS grados,
            COUNT(e.id_estudiante) AS total_estudiantes,
            SUM(CASE WHEN e.sexo = 'Masculino' THEN 1 ELSE 0 END) AS total_masculinos,
            SUM(CASE WHEN e.sexo = 'Femenino' THEN 1 ELSE 0 END) AS total_femeninos,
            SUM(CASE WHEN e.tipo_ins = 'Nuevo' THEN 1 ELSE 0 END) AS total_nuevos,
            SUM(CASE WHEN e.tipo_ins = 'Regular' THEN 1 ELSE 0 END) AS total_regulares,
            SUM(CASE WHEN e.tipo_ins = 'Repitiente' THEN 1 ELSE 0 END) AS total_repitientes
        FROM
            estudiante e
        JOIN
            grados g ON e.grado_id = g.id
        GROUP BY
            e.ins_para, g.nombre
        ORDER BY
            e.ins_para, g.nombre;
    ";

    $resultado = $conexion->query($sql);

    $estadisticas = [];
    if ($resultado->num_rows > 0) {
        while ($fila = $resultado->fetch_assoc()) {
            $estadisticas[] = $fila;
        }
    }

    $conexion->close();

    return $estadisticas;
}
?>