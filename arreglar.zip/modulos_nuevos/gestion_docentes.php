<?php 
include_once $_SERVER['DOCUMENT_ROOT'] . '/sistema-UEBEM/modulos/config.php';
include ('../modulos/verificar_session.php');
include ('../modulos/rol1.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Gestión de docentes</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/fontawesome.css">
    <link rel="stylesheet" type="text/css" href="../css/procesare.css">
    <link rel="stylesheet" type="text/css" href="../css/inicio.css">
    <link rel="stylesheet" type="text/css" href="../lib/datatable/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../lib/datatable/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="../lib/datatable/dataTables.bootstrap.min.css">
    <script src="../node_modules/jquery/dist/jquery.min.js"></script>
    <script src="../lib/datatable/datatables.min.js"></script>
    <script src="../lib/datatable/dataTables.bootstrap.min.js"></script>
    <script src="../lib/datatable/jquery.dataTables.min.js"></script>
    <script src="../js/h.d.js"></script>
    <link rel="stylesheet" href="../css/footer_e.css">

</head>
<body oncontextmenu="return false;">   
    <?php include('../modulos/menu.php')?>
        
    <div class="content">
            
            <center><h2 class="">Lista de docentes</h2></center><br>
            <button style="display: inline-block; background-color: #007bff; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;" onclick="history.back()">Volver</button>
        <table id="tabla" class="table table-hover table-condensed">
            <thead>
                <tr>
                    <th>ID:</th>
                    <th>Cedula:</th>
                    <th>nombres:</th>
                    <th>apellido:</th>
                    <th>grado instucción:</th>
                    <th>Aula asignada</th>
                    <th>Actv/Des</th>
                    
                    <th class="opciones">Opciones</th>
                </tr>    
            </thead>
            
            <tbody>    

            <?php
            include '../modulos/conexion/conndb.php';
        
            // Realizar la consulta a la base de datos
            // Consultar la información del aula asignada a cada docente
$sql = "SELECT docentes.*, aulas.nombre FROM docentes 
INNER JOIN aulas ON docentes.aula_id = aulas.id_aula";
$result= $conexion->query($sql);
          
            
            // Verificar si se obtuvieron resultados

            if ($result->num_rows > 0) {
                // Mostrar los datos en la tabla
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id"] . "</td>";
                    echo "<td>" . $row["cedula"] . "</td>";
                    echo "<td>" . $row["nombres"] . "</td>";
                    echo "<td>" . $row["apellidos"] . "</td>";
                    echo "<td>" . $row["gdo_ins"] . "</td>";
                    echo "<td>" . $row['nombre'] . "</td>"; // Mostrar el nombre o número del aula
                    echo "<td>";
                    if (isset($row['habilitado']) && $row['habilitado']) {
                        echo "<a class='btn btn-danger a btn-eliminar' href='#' onclick='desactivardocente(" . $row['id'] . "); return false;'>Deshabilitar</a>";
                    } else {
                        echo "<input class='btn btn-primary a' type='button' value='Habilitar' onclick='habilitardocente(" . $row['id'] . ");'>";
                    }
                    echo "</td>";
                    echo "<td>";
                    echo " <a class='btn btn-primary a ' href='editard.php?id=" . $row["id"] . "'>Modificar</a>  ";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='31'>No se encontraron docentes registrados</td></tr>";
            }

            // Cerrar la conexión a la base de datos
            $conexion->close();
            ?>
            </tbody>
        </table>
            
    </div>  
    <div class="footer">
    <?php include '../modulos/footer.php'; ?>
</div>          
</body>
</html>
